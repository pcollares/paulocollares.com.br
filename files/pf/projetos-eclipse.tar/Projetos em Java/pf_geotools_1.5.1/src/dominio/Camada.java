package dominio;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.geotools.data.FeatureSource;
import org.geotools.data.FileDataStore;
import org.geotools.data.FileDataStoreFinder;
import org.opengis.feature.simple.SimpleFeature;
import org.opengis.feature.simple.SimpleFeatureType;

public class Camada
{
	private URL		url;
	private FeatureSource<SimpleFeatureType,SimpleFeature> featureSource;
	
	public Camada(File url)
	{		
		try
		{
			this.url = new URL("file://" + url);
		}
		catch(MalformedURLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			featureSource=generateFeatureSource(url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public Camada(FeatureSource featureSource)
	{		
		this.featureSource=featureSource;
	}

	
	public FeatureSource generateFeatureSource(File sourceFile) throws Exception {
		FeatureSource<SimpleFeatureType,SimpleFeature> featureSource;
		FileDataStore store = FileDataStoreFinder.getDataStore(sourceFile);
	    featureSource = store.getFeatureSource();
	    return featureSource;
	}
	
	public URL getUrl()
	{
		return url;
	}

	
	public FeatureSource getFeatureSource() {
		return featureSource;
	}


}
