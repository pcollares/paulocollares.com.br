package face;

import java.awt.event.ActionEvent;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

import org.geotools.map.DefaultMapContext;
import org.geotools.map.MapContext;
import org.geotools.swing.JMapFrame;
import org.geotools.swing.action.SafeAction;

import controle.Dados;
import dominio.Camada;



public class JanelaPrincipal {
	private JButton bntNC;
	private JButton bntLT;
	private JMapFrame mapFrame;
	
	public JanelaPrincipal(){
	 Dados.map = new DefaultMapContext();
     
     mapFrame = new JMapFrame(Dados.map);
     mapFrame.setTitle(Dados.nome);
     mapFrame.enableLayerTable( true );
     mapFrame.enableTool(JMapFrame.Tool.PAN,JMapFrame.Tool.ZOOM,JMapFrame.Tool.RESET); 
     mapFrame.enableStatusBar(true);
     
     JToolBar toolbar = mapFrame.getToolBar();
     bntNC=getBntNC();
     toolbar.add( bntNC );
     bntLT=getBntLT();
     toolbar.add( bntNC );
    
     mapFrame.setExtendedState(mapFrame.MAXIMIZED_BOTH); 
     mapFrame.setVisible(true);
	}
	
	
	private JButton getBntNC() {
			bntNC = new JButton();
			ImageIcon icon = new ImageIcon("nova_camada.gif");
			bntNC.setIcon(icon);
			bntNC.setSize(35, 35);
			bntNC.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					new NovaCamada();
				}
			});
		
		return bntNC;
	}
	
	private JButton getBntLT() {
		bntLT = new JButton();
		//ImageIcon icon = new ImageIcon("nova_camada.gif");
		//bntLT.setIcon(icon);
		bntLT.setText("lt");
		bntLT.setSize(35, 35);
		bntLT.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				mapFrame.enableLayerTable( false );
			}
		});
	
	return bntNC;
}

}