package face;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import controle.Dados;

public class NovaCamada extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton bnfSF = null;
	private JButton bnfBD = null;

	private void fechar(){
		this.dispose();
	}
	
	/**
	 * This is the default constructor
	 */
	public NovaCamada() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 150);
		this.setContentPane(getJContentPane());
		
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension d = tk.getScreenSize();
		Dimension dw = this.getSize();
		this.setLocation((d.width - dw.width) / 2, (d.height - dw.height) / 2);
		
		this.setTitle(Dados.nome+" - Nova Camada");
		
		this.setVisible(true);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.add(getBnfSF(), null);
			jContentPane.add(getBnfBD(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes bnfSF	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBnfSF() {
		if (bnfSF == null) {
			bnfSF = new JButton("Shapefile");
			bnfSF.setBounds(new Rectangle(13, 36, 111, 25));
			bnfSF.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					fechar();
					new NovaCamadaShapefile();
				}
			});
		}
		return bnfSF;
	}

	/**
	 * This method initializes bnfBD	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBnfBD() {
		if (bnfBD == null) {
			bnfBD = new JButton("Banco de Dados");
			bnfBD.setBounds(new Rectangle(137, 37, 127, 26));
			bnfBD.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					fechar();
					new NovaCamadaBanco();
				}
			});
		}
		return bnfBD;
	}

}
