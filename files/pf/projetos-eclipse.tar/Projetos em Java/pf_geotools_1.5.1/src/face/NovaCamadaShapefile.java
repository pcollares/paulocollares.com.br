package face;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

import controle.Dados;
import dominio.Camada;
import dominio.ExtensionFileFilter;

public class NovaCamadaShapefile extends JFrame {

	private static final long serialVersionUID = 1L;
	private String arquivo="";  //  @jve:decl-index=0:
	private String lastPath="D:/shapefiles";  //  @jve:decl-index=0:


	private void fechar(){
		this.dispose();
	}
	
	/**
	 * This is the default constructor
	 */
	public NovaCamadaShapefile() {
		super();
		if (abreArquivo()){
			Camada camada = new Camada(new File(arquivo));
			Dados.map.addLayer(camada.getFeatureSource(), null);
		}
		fechar();
	}

private boolean abreArquivo(){
	JFileChooser chooser = new JFileChooser(new File(lastPath));
	chooser.setDialogTitle(Dados.nome+" - Selecione um Shapefile");
	chooser.setFileFilter(new ExtensionFileFilter("Shapefiles (*.shp)", "shp"));  
	int returnVal = chooser.showOpenDialog(null);
	lastPath=chooser.getSelectedFile().getAbsolutePath();
	if (returnVal == JFileChooser.APPROVE_OPTION) { 
      arquivo=chooser.getSelectedFile().getPath();
      return true;
    }
	return false;
}


}

