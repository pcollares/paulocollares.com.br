package face;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.geotools.data.DataStore;
import org.geotools.data.DataStoreFinder;
import org.geotools.data.FeatureSource;

import controle.Dados;
import dominio.Camada;

public class NovaCamadaBanco extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton bnfSF = null;
	private JButton bnfBD = null;
	private JLabel lbHost = null;
	private JLabel lbBanco = null;
	private JLabel lbUser = null;
	private JLabel lbSenha = null;
	private JTextField tfHost = null;
	private JTextField tfBanco = null;
	private JTextField tfUser = null;
	private JPasswordField tfSenha = null;
	private JButton bntOk = null;
	private JLabel lbTabela = null;
	private JTextField tfTabela = null;

	private void fechar(){
		this.dispose();
	}
	
	/**
	 * This is the default constructor
	 */
	public NovaCamadaBanco() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(300, 246);
		this.setContentPane(getJContentPane());
		
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension d = tk.getScreenSize();
		Dimension dw = this.getSize();
		this.setLocation((d.width - dw.width) / 2, (d.height - dw.height) / 2);
		
		this.setTitle(Dados.nome+" - Nova Camada - Banco de Dados");
		
		this.setVisible(true);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			lbTabela = new JLabel();
			lbTabela.setBounds(new Rectangle(15, 137, 67, 16));
			lbTabela.setText("Tabela: ");
			lbSenha = new JLabel();
			lbSenha.setBounds(new Rectangle(14, 107, 73, 16));
			lbSenha.setText("Senha:");
			lbUser = new JLabel();
			lbUser.setBounds(new Rectangle(14, 76, 73, 16));
			lbUser.setText("Usu�rio: ");
			lbBanco = new JLabel();
			lbBanco.setBounds(new Rectangle(14, 47, 65, 16));
			lbBanco.setText("Banco: ");
			lbHost = new JLabel();
			lbHost.setBounds(new Rectangle(14, 14, 38, 16));
			lbHost.setText("Host: ");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(lbHost, null);
			jContentPane.add(lbBanco, null);
			jContentPane.add(lbUser, null);
			jContentPane.add(lbSenha, null);
			jContentPane.add(getTfHost(), null);
			jContentPane.add(getTfBanco(), null);
			jContentPane.add(getTfUser(), null);
			jContentPane.add(getTfSenha(), null);
			jContentPane.add(getBntOk(), null);
			jContentPane.add(lbTabela, null);
			jContentPane.add(getTfTabela(), null);
			
		}
		return jContentPane;
	}

	/**
	 * This method initializes tfHost	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTfHost() {
		if (tfHost == null) {
			tfHost = new JTextField("localhost");
			tfHost.setBounds(new Rectangle(87, 12, 177, 21));
		}
		return tfHost;
	}

	/**
	 * This method initializes tfBanco	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTfBanco() {
		if (tfBanco == null) {
			tfBanco = new JTextField("mapas");
			tfBanco.setBounds(new Rectangle(91, 43, 176, 22));
		}
		return tfBanco;
	}

	/**
	 * This method initializes tfUser	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTfUser() {
		if (tfUser == null) {
			tfUser = new JTextField("postgres");
			tfUser.setBounds(new Rectangle(93, 74, 175, 19));
		}
		return tfUser;
	}

	/**
	 * This method initializes tfSenha	
	 * 	
	 * @return javax.swing.JPasswordField	
	 */
	private JPasswordField getTfSenha() {
		if (tfSenha == null) {
			tfSenha = new JPasswordField("12345678");
			tfSenha.setBounds(new Rectangle(94, 106, 176, 18));
		}
		return tfSenha;
	}

	/**
	 * This method initializes bntOk	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBntOk() {
		if (bntOk == null) {
			bntOk = new JButton("OK");
			bntOk.setBounds(new Rectangle(88, 161, 100, 36));
			bntOk.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					 Map params = new HashMap();
				        params.put("dbtype", "postgis");
				        params.put("host", tfHost.getText());
				        params.put("port", new Integer(5432));
				        params.put("database", tfBanco.getText());
				        params.put("user", tfUser.getText());
				        params.put("passwd", tfSenha.getText());
				        
				        FeatureSource fsWorld=null;
						try {
							DataStore pgDatastore = DataStoreFinder.getDataStore(params);
							fsWorld = pgDatastore.getFeatureSource(tfTabela.getText());
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
				        Camada camada=new Camada(fsWorld);
				        Dados.map.addLayer(camada.getFeatureSource(),null);
				        fechar();
				}
			});
		}
		return bntOk;
	}

	/**
	 * This method initializes tfTabela	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTfTabela() {
		if (tfTabela == null) {
			tfTabela = new JTextField("mundo");
			tfTabela.setBounds(new Rectangle(91, 136, 175, 20));
		}
		return tfTabela;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
