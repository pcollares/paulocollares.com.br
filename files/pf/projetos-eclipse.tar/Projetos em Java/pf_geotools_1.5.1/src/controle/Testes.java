package controle;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import org.geotools.data.FeatureSource;
import org.geotools.data.FileDataStore;
import org.geotools.data.FileDataStoreFinder;
import org.opengis.feature.simple.SimpleFeature;
import org.opengis.feature.simple.SimpleFeatureType;


public class Testes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FeatureSource<SimpleFeatureType,SimpleFeature> featureSource=null;
		
		//File sourceFile = JFileDataStoreChooser.showOpenFile("shp", null);
		//File sourceFile=new File("C:/shapefiles/br_uf/BR_UF.shp");
		File sourceFile=new File("C:/shapefiles/Hidrografia/municipios.shp");
		//File sourceFile=new File("C:/shapefiles/cities/cities.shp");
		
   	 try {
		FileDataStore store = FileDataStoreFinder.getDataStore(sourceFile);
		    featureSource = store.getFeatureSource();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	String s =featureSource.getSchema().getAttributeDescriptors().toString();
	String [] array=s.split("<");
	String s2="";
	
	for (int i=2;i<array.length;i++){
		if (array[i]!=null){
			String temp=array[i];
			int fim=temp.indexOf(":");       
			temp=temp.substring(0,fim);
			s2+="="+temp;
		}
	}
	
	String [] retorno=s2.split("=");
	Arrays.sort(retorno);
	
	for (int i=0;i<retorno.length;i++)
		System.out.println(retorno[i]);
    
	
       
       
	}

}
