package controle;

import face.JanelaPrincipal;


public class Programa {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
			try {
				Class.forName("org.geotools.coverage.grid.GridCoverage2D");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			new JanelaPrincipal();
			//new NovaCamada();
	}

}
