package controle;

import org.geotools.map.MapContext;

import dominio.Camada;

public class Dados {
	public static  MapContext map;
	public static String nome="PF 1.5.1";
}
