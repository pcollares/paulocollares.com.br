package dominio;

import java.awt.Color;

public class Label {

	private String campo;
	private Color cor;
	private String fonte;
	private int fontSize;
	
	public Label (String campo){
	
		this.campo=campo;
		cor=Color.black;
		fonte="Lucida Sans";
		fontSize=10;
			
	}
	
	public Label (String campo,Color cor){
		
		this.campo=campo;
		this.cor=cor;
		fonte="Lucida Sans";
		fontSize=10;
		
	}
	
	public Label (String campo,Color cor,int fontSize){
			
		this.campo=campo;
		this.cor=cor;
		fonte="Lucida Sans";
		this.fontSize=fontSize;
		
	}
	
	public Label (String campo,Color cor,int fontSize,String fonte){
		
		this.campo=campo;
		this.cor=cor;
		this.fonte=fonte;
		this.fontSize=fontSize;
		
	}

	public String getCampo() {
		return campo;
	}

	public Color getCor() {
		return cor;
	}

	public String getFonte() {
		return fonte;
	}

	public int getFontSize() {
		return fontSize;
	}
	
}
