package dominio;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.io.IOException;

import javax.swing.JComponent;

import org.geotools.map.MapContext;
import org.geotools.renderer.shape.ShapefileRenderer;

import com.vividsolutions.jts.geom.Coordinate;
import com.vividsolutions.jts.geom.Envelope;

/**
 * Esta classe representa um componente gr�fico capaz de desenhar o conte�do
 * (geometria) de uma inst�ncia de ShapefileDataStore.
 */
public class ShapefileComponent extends JComponent {

	private ShapefileRenderer renderer;
	private Envelope envelope;
	private Coordinate pos;
	private double zoom;
	private final int width = 640;
	private final int height = 640;
	private MapContext mc;

	//construtor
	public ShapefileComponent(MapContext mc) throws IOException {

		this.mc = mc;

		// Agora com o contexto criamos um ShapefileRenderer
		renderer = new ShapefileRenderer(this.mc);
		envelope = this.mc.getLayerBounds();
		pos = new Coordinate((envelope.getMinX() + envelope.getMaxX()) / 2,
				(envelope.getMinY() + envelope.getMaxY()) / 2);
		zoom = 1;
	}
	
	//////////
	
	public void atualiza(MapContext mc) throws IOException{
		this.mc = mc;

		// Agora com o contexto criamos um ShapefileRenderer
		renderer = new ShapefileRenderer(this.mc);
		envelope = this.mc.getLayerBounds();
		pos = new Coordinate((envelope.getMinX() + envelope.getMaxX()) / 2,
				(envelope.getMinY() + envelope.getMaxY()) / 2);
		zoom = 1;
		this.repaint();

	}
	
	public Dimension getMaximumSize() {
		return getPreferredSize();
	}

	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	public Dimension getPreferredSize() {
		return new Dimension(width, height);
	}

	protected void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		g2d.setColor(Color.WHITE);
		g2d.fillRect(0, 0, width, height);
		// Uma AffineTransform que mapeie dados no shapefile com a �rea para
		// plotagem
		AffineTransform at = new AffineTransform();
		// Calculamos a escala
		double escala = (Math.min(getWidth() / envelope.getWidth(), getHeight()
				/ envelope.getHeight()) * zoom);
		// Fazemos a transla��o para o centro do componente.
		at.translate(getWidth() / 2, getHeight() / 2);
		// Mudamos a escala vertical para corrigir a orienta��o.
		at.scale(escala, -escala);
		// Fazemos a transla��o para o centro da geometria.
		at.translate(-pos.x, -pos.y);
		// Pintamos a geometria no componente.
		renderer.paint(g2d, getBounds(), at);
	}

	/**
	 * @param zoom
	 *            the zoom to set
	 */
	public void setZoom(double zoom) {
		this.zoom = zoom;
	}

	/**
	 * @return the zoom
	 */
	public double getZoom() {
		return zoom;
	}

	public void setMc(MapContext mc) {
		this.mc = mc;
	}

	public Coordinate getPos() {
		return pos;
	}

	public void setPos(Coordinate pos) {
		this.pos = pos;
	}

}