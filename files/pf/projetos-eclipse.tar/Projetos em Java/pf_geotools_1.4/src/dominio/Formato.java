package dominio;

import java.awt.Color;

public class Formato
{
	private String	filtro;
	private Color	corFundo;
	private String	marca;
	private Color	corMarca;

	public Formato(Color corFundo)
	{
		super();
		this.filtro = filtro;
		this.corFundo = corFundo;
		this.marca = marca;
		this.corMarca = corMarca;
	}

	public Formato(String filtro, Color corFundo)
	{
		super();
		this.filtro = filtro;
		this.corFundo = corFundo;
		this.marca = marca;
		this.corMarca = corMarca;
	}

	public Formato(String filtro, Color corFundo, String marca, Color corMarca)
	{
		super();
		this.filtro = filtro;
		this.corFundo = corFundo;
		this.marca = marca;
		this.corMarca = corMarca;
	}

	public String getFiltro()
	{
		return filtro;
	}

	public void setFiltro(String filtro)
	{
		this.filtro = filtro;
	}

	public Color getCorFundo()
	{
		return corFundo;
	}

	public void setCorFundo(Color corFundo)
	{
		this.corFundo = corFundo;
	}

	public String getMarca()
	{
		return marca;
	}

	public void setMarca(String marca)
	{
		this.marca = marca;
	}

	public Color getCorMarca()
	{
		return corMarca;
	}

	public void setCorMarca(Color corMarca)
	{
		this.corMarca = corMarca;
	}
}
