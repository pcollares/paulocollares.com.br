package dominio;

import java.awt.Color;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.geotools.data.shapefile.ShapefileDataStore;
import org.geotools.map.DefaultMapLayer;
import org.geotools.styling.Style;

import controle.Metodos;

public class Camada
{
	public final static int PONTO = 1;
	public final static int LINHA = 2;
	public final static int SOLIDO = 3;
	public final static int TEXTO = 4;
	

	private URL		url;
	private Color	cor;
	private String	nome;
	private Label label;
	private boolean	mostra;
	private int		tipo;
	private List<Formato> listaFormatos;
	private Style style;
	private ShapefileDataStore shapefileDataStore;
	private String info;
	private int layerIndex;
	


	public Camada(String url, String nome, int tipo, boolean mostra, Label label, Formato...formatos)//varargs
	{		
		try
		{
			this.url = new URL("file://" + url);
		}
		catch(MalformedURLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.cor = cor;//?
		this.nome = nome;
		this.tipo = tipo;
		this.label=label;
		this.mostra = mostra;
		this.listaFormatos = new ArrayList<Formato>();
		for(Formato f : formatos)
			this.listaFormatos.add(f);
		if(formatos.length == 0)
			this.listaFormatos.add(new Formato(Color.BLACK));
		
		style=(Style)Metodos.criaStyle(this);
		try {
			this.shapefileDataStore = new ShapefileDataStore(this.url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		info=this.buildInfo(shapefileDataStore);
	}

	/**
	 * @return the url
	 */
	public int getLayerIndex() {
		return layerIndex;
	}

	public void setLayerIndex(int layerIndex) {
		this.layerIndex = layerIndex;
	}
	
	public URL getUrl()
	{
		return url;
	}

	/**
	 * @return the cor
	 */
	public Color getCor()
	{
		return cor;
	}

	/**
	 * @return the nome
	 */
	public String getNome()
	{
		return nome;
	}
	
	/**
	 * @return the label
	 */
	public Label getLabel()
	{
		return label;
	}
	
	public int getTipo()
	{
		return tipo;
	}

	public boolean podeMostrar()
	{
		return mostra;
	}

	public void setMostra(boolean mostra)
	{
		this.mostra = mostra;
	}

	public List<Formato> getFormatos()
	{
		return this.listaFormatos;
	}
	public String toString(){
		return nome;
	}
	
	public String getInfo(){
		return this.info;
	}
	
	public String buildInfo(ShapefileDataStore s){
		String info;
		info="<html>";
		info+="Nome: "+nome;
		info+="<br>Tipo: "+tipo;
		info+="<br>URL: "+url;
		if (label!=null)
			info+="<br>Label: "+label.getCampo();
		info+="<br>Formatos:";
		for(Formato f : listaFormatos)
			info+="<br> - Marca: "+f.getMarca()+" - Filtro: "+f.getFiltro()+" Cor de Fundo: "+f.getCorFundo()+" Cor da Marca: "+f.getCorMarca();
		
		try {
			info+="<br><br>Atributos:";				
			for(Object o : s.getSchema().getAttributeDescriptors())
				info+="<br> - "+o;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		info+="</html>";
		return info;
	}

	public Style getStyle() {
		return style;
	}

	public ShapefileDataStore getShapefileDataStore() {
		return shapefileDataStore;
	}
}
