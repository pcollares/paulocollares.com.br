package face;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controle.Dados;
import dominio.Camada;
import dominio.ExtensionFileFilter;

public class NovaCamada extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JLabel lbArq = null;
	private JLabel lbArqPath = null;
	private JLabel lbNome = null;
	private JTextField tfNome = null;
	private JComboBox cbTipo = null;
	private JLabel lbTipo = null;
	private JButton bntOk = null;
	private JButton bntArq = null;
	private String arquivo="";  //  @jve:decl-index=0:
	
	private void fechar(){
		this.dispose();
	}
	
	/**
	 * This is the default constructor
	 */
	public NovaCamada() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(600, 300);
		this.setContentPane(getJContentPane());
		
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension d = tk.getScreenSize();
		Dimension dw = this.getSize();
		this.setLocation((d.width - dw.width) / 2, (d.height - dw.height) / 2);
		
		this.setTitle("Nova Camada");
		this.setVisible(true);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			lbTipo = new JLabel();
			lbTipo.setBounds(new Rectangle(15, 90, 72, 16));
			lbTipo.setText("Tipo: ");
			lbNome = new JLabel();
			lbNome.setBounds(new Rectangle(16, 54, 75, 16));
			lbNome.setText("Nome: ");
			lbArq = new JLabel();
			lbArq.setBounds(new Rectangle(15, 15, 76, 16));
			lbArq.setText("Arquivo: ");
			lbArqPath = new JLabel();
			lbArqPath.setBounds(new Rectangle(180, 15, 300, 21));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(lbArq, null);
			jContentPane.add(lbArqPath, null);
			jContentPane.add(getBntArq(), null);
			jContentPane.add(lbNome, null);
			jContentPane.add(getTfNome(), null);
			jContentPane.add(getCbTipo(), null);
			jContentPane.add(lbTipo, null);
			jContentPane.add(getBntOk(), null);
		}
		return jContentPane;
	}

	
	/**
	 * This method initializes tfNome	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTfNome() {
		if (tfNome == null) {
			tfNome = new JTextField();
			tfNome.setBounds(new Rectangle(90, 54, 211, 20));
		}
		return tfNome;
	}

	/**
	 * This method initializes cbTipo	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getCbTipo() {
		if (cbTipo == null) {
			cbTipo = new JComboBox();
			cbTipo.setBounds(new Rectangle(90, 90, 204, 17));
			cbTipo.addItem(Camada.LINHA);
			cbTipo.addItem(Camada.SOLIDO);
			cbTipo.addItem(Camada.PONTO);
		}
		return cbTipo;
	}

	/**
	 * This method initializes bntOk	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBntOk() {
		if (bntOk == null) {
			bntOk = new JButton();
			bntOk.setBounds(new Rectangle(240, 210, 84, 34));
			bntOk.setText("OK");
			bntOk.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					Integer cb=(Integer) cbTipo.getSelectedItem();
					Camada c = new Camada(arquivo,tfNome.getText(),cb,false,null);
					Dados.lista.add(c);
					
					fechar();
				}
			});
		}
		return bntOk;
	}



private JButton getBntArq() {
	if (bntArq == null) {
		bntArq = new JButton();
		bntArq.setBounds(new Rectangle(90, 15, 84, 20));
		bntArq.setText("Arquivo");
		bntArq.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				JFileChooser chooser = new JFileChooser(new File(Dados.lastPath));
				chooser.setDialogTitle("Selecione um Shapefile");
				chooser.setFileFilter(new ExtensionFileFilter("Shapefiles (*.shp)", "shp"));  
				int returnVal = chooser.showOpenDialog(jContentPane);
				Dados.lastPath=chooser.getSelectedFile().getAbsolutePath();
				if (returnVal == JFileChooser.APPROVE_OPTION) { 
			      arquivo=chooser.getSelectedFile().getPath();
			      lbArqPath.setText(arquivo);
			      bntOk.setEnabled(true);
			    }else{
			    	lbArqPath.setText("Arquivo inv�lido");
			    	bntOk.setEnabled(false);
			    }
			}
		});
	}
	return bntArq;
}

}

