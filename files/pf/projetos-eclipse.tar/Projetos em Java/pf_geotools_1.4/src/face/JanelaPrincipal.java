package face;

import java.awt.GridBagLayout;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.net.MalformedURLException;

import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeSelectionModel;

import org.geotools.map.DefaultMapContext;
import org.geotools.map.MapContext;
import org.geotools.map.MapLayer;
import org.geotools.styling.Style;

import controle.Dados;
import dominio.Camada;
import dominio.ShapefileComponent;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.GridLayout;
import java.awt.BorderLayout;

public class JanelaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JSplitPane splitPane = null;
	private JTree arvore = null;
	private JPanel mapa = null;
	private final int MAX_ZOOM = 15;
	private JSplitPane splitPane2 = null;
	private JLabel descricao = null;
	private MapContext mc=new DefaultMapContext();;  //  @jve:decl-index=0:
	private ShapefileComponent sc=null;
	private JMenuBar menu = null;
	private JMenu menuArquivo = null;
	private JMenuItem menuCamadaNova = null;
	private JMenu menuCamada = null;
	private JMenuItem menuCamadaAtualizar = null;
	private JScrollPane scrollTree =null;
	private JMenu menuEditar = null;
	private JMenu menuZoom = null;
	private JMenuItem menuMaisZoom = null;
	private JMenuItem menuMenosZoom = null;
	private JMenuItem menuZoomDefault = null;
	private JTabbedPane abas = null;
	private JTextField tfFiltro = null;
	private JButton btFiltroOk = null;
	
	public void atualizaArvore(){
		scrollTree = new JScrollPane(getArvore());
		splitPane.setDividerLocation(150);
		splitPane.setLeftComponent(scrollTree);
	}
	
	private void trocaZoom(double zoom) {
		boolean troca = true;
		if ((zoom < 1) || (zoom > MAX_ZOOM))
			troca = false;
		if (troca)
			sc.setZoom(zoom);

	}
	/**
	 * This is the default constructor
	 */
	public JanelaPrincipal() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(900, 450);
		this.setJMenuBar(getMenu());
		this.setContentPane(getJContentPane());
		this.setTitle("Projeto Final - 1.4");
		this.setExtendedState(MAXIMIZED_BOTH);   

		this.setVisible(true);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BoxLayout(getJContentPane(), BoxLayout.X_AXIS));
			
			jContentPane.add(getSplitPane(), null);
			
		}
		return jContentPane;
	}

	/**
	 * This method initializes splitPane	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getSplitPane() {
		if (splitPane == null) {
			splitPane = new JSplitPane();
			splitPane.setOneTouchExpandable(true);
		
			splitPane.setDividerLocation(150);

			scrollTree = new JScrollPane(getArvore());
			splitPane.setLeftComponent(scrollTree);
			splitPane.setRightComponent(getSplitPane2());
			
		}
		return splitPane;
	}

	/**
	 * This method initializes splitPane2	
	 * 	
	 * @return javax.swing.JSplitPane	
	 */
	private JSplitPane getSplitPane2() {
		if (splitPane2 == null) {
			descricao = new JLabel();
			descricao.setText("");
			splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
			splitPane2.setOneTouchExpandable(true);
			splitPane2.setDividerLocation(500);
			JScrollPane scrollLabel = new JScrollPane(descricao);
			abas=new JTabbedPane();
			splitPane2.setRightComponent(abas);
			splitPane2.setTopComponent(getMapa());
			
			abas.addTab("Descri��o", null, scrollLabel,"Descri��o");
			abas.setMnemonicAt(0, KeyEvent.VK_1);
			
			JPanel filtros=new JPanel();
			filtros.setLayout(new BoxLayout(filtros, BoxLayout.Y_AXIS));
			JScrollPane scrollFiltro = new JScrollPane(filtros);
			
			JLabel lbFiltro=new JLabel("Filtros");
			filtros.add(lbFiltro, null);
			filtros.add(getTfFiltro(), null);
			filtros.add(getBtFiltroOk(), null);
			
			abas.addTab("Filtros", null, scrollFiltro,"Filtros");
			abas.setMnemonicAt(1, KeyEvent.VK_2);
			
		}
		return splitPane2;
	}
	
	/**
	 * This method initializes arvore	
	 * 	
	 * @return javax.swing.JTree	
	 */
	private JTree getArvore() {
				
			DefaultMutableTreeNode root = new DefaultMutableTreeNode("Camadas");
			
			for (Object o : Dados.lista) {
				final Camada c = (Camada) o;
				DefaultMutableTreeNode child = new DefaultMutableTreeNode(c);
				root.add(child);
				
			}
		
			arvore = new JTree(root);
			arvore.getSelectionModel().setSelectionMode (TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
		
			 MouseListener ml = new MouseAdapter() {
			     public void mousePressed(MouseEvent e) {
			         int selRow = arvore.getRowForLocation(e.getX(), e.getY());
			         //TreePath selPath = arvore.getPathForLocation(e.getX(), e.getY());
			         DefaultMutableTreeNode node = (DefaultMutableTreeNode) arvore.getLastSelectedPathComponent();
	            	 Object nodeInfo = node.getUserObject();
	            	 Camada c = (Camada) nodeInfo;
	            	 
			         if(selRow != -1) {
			             if(e.getClickCount() == 1) {//um clique
			            	 descricao.setText(c.getInfo());
			             }
			             else if(e.getClickCount() == 2) {//dois cliques
			            	 			
			 				 if (c.podeMostrar())
			 					 c.setMostra(false);
			 				 else
			 					 c.setMostra(true);
			 				
			 				if (c.podeMostrar()){
				 				Style style=(Style) c.getStyle();
				 				try {
				 					mc.addLayer(c.getShapefileDataStore().getFeatureSource(), style);
				 					MapLayer layers[]=mc.getLayers();
				 					c.setLayerIndex(mc.indexOf(layers[layers.length-1]));
				 				} catch (MalformedURLException e1) {
				 					// TODO Auto-generated catch block
				 					e1.printStackTrace();
				 				} catch (IOException e1) {
				 					// TODO Auto-generated catch block
				 					e1.printStackTrace();
				 				}
				 				
				 				if (sc==null)
					         	 	try {
					 					sc=new ShapefileComponent(mc);
					 				} catch (IOException e1) {
					 					// TODO Auto-generated catch block
					 					e1.printStackTrace();
					 				}
								else
									try {
										sc.atualiza(mc);
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}	
									
			 				}else{
			 					mc.removeLayer(c.getLayerIndex());
			 					try {
									sc.atualiza(mc);
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}	
								
			 				}
			 				
			 				mapa.add(sc);
			 				mapa.updateUI();
			 						
			            	}
			         }
			     }
			 };
			 arvore.addMouseListener(ml);
			
			
			
		
		return arvore;
	}

	
	
	/**
	 * This method initializes mapa	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getMapa() {
		if (mapa == null) {
			mapa = new JPanel();
			mapa.setLayout(new GridBagLayout());
		}
		return mapa;
	}

	/**
	 * This method initializes menu	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getMenu() {
		if (menu == null) {
			menu = new JMenuBar();
			menu.add(getMenuArquivo());
			menu.add(getMenuEditar());
			menu.add(getMenuCamada());
		}
		return menu;
	}

	/**
	 * This method initializes menuArquivo	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getMenuArquivo() {
		if (menuArquivo == null) {
			menuArquivo = new JMenu("Arquivo");
		}
		return menuArquivo;
	}

	/**
	 * This method initializes menuCamadaNova	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getMenuCamadaNova() {
		if (menuCamadaNova == null) {
			menuCamadaNova = new JMenuItem("Nova Camada");
			menuCamadaNova.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					new NovaCamada();
				}
			});
		}
		return menuCamadaNova;
	}

	/**
	 * This method initializes menuCamada	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getMenuCamada() {
		if (menuCamada == null) {
			menuCamada = new JMenu("Camadas");
			menuCamada.add(getMenuCamadaNova());
			menuCamada.add(getMenuCamadaAtualizar());
		}
		return menuCamada;
	}

	/**
	 * This method initializes menuCamadaAtualizar	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getMenuCamadaAtualizar() {
		if (menuCamadaAtualizar == null) {
			menuCamadaAtualizar = new JMenuItem("Atualizar");
			menuCamadaAtualizar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					
					atualizaArvore();			
				}
			});
		}
		return menuCamadaAtualizar;
	}

	/**
	 * This method initializes menuEditar	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getMenuEditar() {
		if (menuEditar == null) {
			menuEditar = new JMenu("Editar");
			menuEditar.add(getMenuZoom());
		}
		return menuEditar;
	}

	/**
	 * This method initializes menuZoom	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getMenuZoom() {
		if (menuZoom == null) {
			menuZoom = new JMenu("Zoom");
			menuZoom.add(getMenuMaisZoom());
			menuZoom.add(getMenuMenosZoom());
			menuZoom.add(getMenuZoomDefault());
		}
		return menuZoom;
	}

	/**
	 * This method initializes menuMaisZoom	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getMenuMaisZoom() {
		if (menuMaisZoom == null) {
			menuMaisZoom = new JMenuItem("Mais");
			menuMaisZoom.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					double zoom = sc.getZoom() + 1;
					trocaZoom(zoom);
					sc.repaint();
				}
			});
		}
		return menuMaisZoom;
	}

	/**
	 * This method initializes menuMenosZoom	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getMenuMenosZoom() {
		if (menuMenosZoom == null) {
			menuMenosZoom = new JMenuItem("Menos");
			menuMenosZoom.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					double zoom = sc.getZoom() - 1;
					trocaZoom(zoom);
					sc.repaint();
				}
			});
		}
		return menuMenosZoom;
	}

	/**
	 * This method initializes menuZoomDefault	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getMenuZoomDefault() {
		if (menuZoomDefault == null) {
			menuZoomDefault = new JMenuItem("Padr�o");
			menuZoomDefault.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					trocaZoom(1);
					sc.repaint();
				}
			});
		}
		return menuZoomDefault;
	}

	/**
	 * This method initializes tfFiltro	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTfFiltro() {
		if (tfFiltro == null) {
			tfFiltro = new JTextField();
		}
		return tfFiltro;
	}

	/**
	 * This method initializes btFiltroOk	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtFiltroOk() {
		if (btFiltroOk == null) {
			btFiltroOk = new JButton("Ok");
		}
		return btFiltroOk;
	}

	


	
}  //  @jve:decl-index=0:visual-constraint="10,10"
