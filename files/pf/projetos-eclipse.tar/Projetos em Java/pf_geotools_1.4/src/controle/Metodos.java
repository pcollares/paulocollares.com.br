package controle;

import java.awt.Color;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import org.geotools.data.shapefile.ShapefileDataStore;
import org.geotools.filter.text.cql2.CQL;
import org.geotools.filter.text.cql2.CQLException;
import org.geotools.map.MapContext;
import org.geotools.styling.AnchorPoint;
import org.geotools.styling.FeatureTypeStyle;
import org.geotools.styling.Font;
import org.geotools.styling.Graphic;
import org.geotools.styling.LineSymbolizer;
import org.geotools.styling.Mark;
import org.geotools.styling.PointPlacement;
import org.geotools.styling.PointSymbolizer;
import org.geotools.styling.PolygonSymbolizer;
import org.geotools.styling.Rule;
import org.geotools.styling.Style;
import org.geotools.styling.StyleBuilder;
import org.geotools.styling.Symbolizer;
import org.geotools.styling.TextSymbolizer;
import org.opengis.filter.Filter;

import dominio.Camada;
import dominio.Formato;
import dominio.Label;
import dominio.ShapefileComponent;


public class Metodos {
	public static Style criaStyle(Camada c)
	{
		
		StyleBuilder sb = new StyleBuilder();
		Style style = sb.createStyle();
		
		try
		{
			
					// Criamos um Style
					switch(c.getTipo())
					{
						case Camada.LINHA:
							for(Formato f : c.getFormatos())
							{
								LineSymbolizer ls = sb.createLineSymbolizer(f.getCorFundo(), 1);
								Rule rp=null;
								TextSymbolizer ts=null;
								Label l=c.getLabel();
								if (l!=null){
									ts = sb.createTextSymbolizer(l.getCor(), sb.createFont(l.getFonte(), l.getFontSize()), l.getCampo());
									rp = sb.createRule(new Symbolizer[]{ls,ts});
								}else{
									rp = sb.createRule(new Symbolizer[]{ls});
								}
								
								if(f.getFiltro() != null)
								{
									Filter filtro = CQL.toFilter(f.getFiltro());
									rp.setFilter(filtro);
								}
								FeatureTypeStyle fts = sb.createFeatureTypeStyle(null, rp);
								style.addFeatureTypeStyle(fts);
							}
							break;
						case Camada.SOLIDO:
							for(Formato f : c.getFormatos())
							{
								PolygonSymbolizer ps = sb.createPolygonSymbolizer(f.getCorFundo(), Color.BLACK, 1);
								Rule rp=null;
								TextSymbolizer ts=null;
								Label l=c.getLabel();
								if (l!=null){
									ts = sb.createTextSymbolizer(l.getCor(), sb.createFont(l.getFonte(), l.getFontSize()), l.getCampo());
									rp = sb.createRule(new Symbolizer[]{ps,ts});
								}else{
									rp = sb.createRule(new Symbolizer[]{ps});
								}
																
								if(f.getFiltro() != null)
								{
									Filter filtro = CQL.toFilter(f.getFiltro());
									rp.setFilter(filtro);
								}
								FeatureTypeStyle fts = sb.createFeatureTypeStyle(null, rp);
								style.addFeatureTypeStyle(fts);
								
							}
							break;
						case Camada.PONTO:
							for(Formato f : c.getFormatos())
							{
								Mark yellowTri = sb.createMark(f.getMarca(), f.getCorMarca(), Color.BLACK, 0);
								Graphic grArch = sb.createGraphic(null, yellowTri, null, 0.6, 10, 0.7);
								PointSymbolizer pts = sb.createPointSymbolizer(grArch);
								
								Rule rp=null;
								TextSymbolizer ts=null;
								Label l=c.getLabel();
								if (l!=null){
									ts = sb.createTextSymbolizer(l.getCor(), sb.createFont(l.getFonte(), l.getFontSize()), l.getCampo());
									rp = sb.createRule(new Symbolizer[]{pts,ts});
								}else{
									rp = sb.createRule(new Symbolizer[]{pts});
								}
								
								if(f.getFiltro() != null)
								{
									Filter filtro = CQL.toFilter(f.getFiltro());
									rp.setFilter(filtro);
								}
								FeatureTypeStyle fts = sb.createFeatureTypeStyle(null, rp);
								style.addFeatureTypeStyle(fts);
							}
							break;
						case Camada.TEXTO:
							AnchorPoint anchorPoint = sb.createAnchorPoint(0, 0);
							PointPlacement pointPlacement = sb.createPointPlacement(anchorPoint, null, sb.literalExpression(0));
							TextSymbolizer ts = sb.createTextSymbolizer(sb.createFill(Color.BLACK), new Font[]{sb.createFont("Lucida Sans", 10),
									sb.createFont("Arial", 10)}, sb.createHalo(), null, pointPlacement, null);
							style = sb.createStyle(ts);
							break;
					}
			
				
				
			
		}
		catch(CQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return style;
	}

		
	public static ShapefileComponent criaShapefileComponent(MapContext mc){
		ShapefileComponent sc=null;
		try {
			sc = new ShapefileComponent(mc);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return sc;
	}
	
}
