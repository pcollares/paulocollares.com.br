package controle;

import java.util.ArrayList;

import org.geotools.map.DefaultMapContext;
import org.geotools.map.MapContext;

import dominio.Camada;
import dominio.ShapefileComponent;

public class Dados {
	
	public static String lastPath="c:/shapefiles/";
	public static ArrayList<Camada> lista = new ArrayList<Camada>();
}
