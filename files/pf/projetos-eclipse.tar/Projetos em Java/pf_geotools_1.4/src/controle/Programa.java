package controle;

import java.awt.Color;
import java.io.IOException;

import org.geotools.styling.StyleBuilder;

import dominio.Camada;
import dominio.Formato;
import dominio.Label;
import face.JanelaPrincipal;

public class Programa {
	public static void main(String[] args) throws IOException 
	{
		
		Camada c = new Camada("D:/shapefiles/br_regioes/BR_Regioes.shp", "Brasil Regi�es", Camada.SOLIDO, false,
				new Label ("NOME"), 
				 
	             new Formato("SIGLA Like 'SE'", Color.LIGHT_GRAY),
	              new Formato("SIGLA Like 'NE'", Color.YELLOW),
	              new Formato("SIGLA Like 'CO'", Color.BLUE),
	              new Formato("SIGLA Like 'NO'", Color.GREEN),
	              new Formato("SIGLA Like 'SU'", Color.MAGENTA)
				);
	
		Camada c2 = new Camada("D:/shapefiles/br_rodovias/BR_Rodovias.shp", "Brasil Rodovias", Camada.LINHA, false,
				new Label ("RODOVIA1"),
				new Formato("RODOVIA2 EXISTS", Color.RED),
				new Formato("RODOVIA2 DOES-NOT-EXIST", Color.BLACK));
		
		Camada c3 = new Camada("D:/shapefiles/br_uf/BR_UF.shp", "Brasil Estados", Camada.SOLIDO, false,
				null,
				new Formato("POPMUNIC > 2000000", Color.LIGHT_GRAY),
				new Formato("POPMUNIC <= 2000000", Color.RED)
      			);

		Camada c4 = new Camada("D:/shapefiles/br_contorno/BR_Contorno.shp", "Brasil Contorno" ,Camada.SOLIDO, false,null);
		
		Camada c5 = new Camada("D:/shapefiles/33me2500g/33me2500g.shp", "Rio de Janeiro", Camada.LINHA, false,null,
				   new Formato(null, Color.ORANGE));

		Camada c6 = new Camada("D:/shapefiles/Hidrografia/municipios.shp", "Rios", Camada.LINHA, false,null);

		Camada c7 = new Camada("D:/shapefiles/Alertas/Alertas02Ago.shp", "Alertas", Camada.PONTO, false,
				new Label("Classifica"),
		   	   new Formato("Classifica Like 'Mais de 18 meses%'", Color.GREEN, StyleBuilder.MARK_CROSS, Color.GRAY),
			   new Formato("Classifica Like 'Entre 6 e 12 meses%'", Color.YELLOW, StyleBuilder.MARK_CIRCLE, Color.CYAN));

		Camada c8 = new Camada("D:/shapefiles/varios/countries.shp","Mundo",Camada.SOLIDO, false,
					new Label("CNTRY_NAME",Color.red,15),
					new Formato("COLOR_MAP==1",Color.cyan),
					new Formato("COLOR_MAP==2",Color.blue),
					new Formato("COLOR_MAP==3",Color.yellow),
					new Formato("COLOR_MAP==4",Color.red),
					new Formato("COLOR_MAP==5",Color.green),
					new Formato("COLOR_MAP==6",Color.pink),
					new Formato("COLOR_MAP==7",Color.magenta),
					new Formato("COLOR_MAP==8",Color.orange));

		Camada c9 = new Camada("D:/shapefiles/varios/cities.shp", "Cidades", Camada.PONTO, false,
					new Label("CITY_NAME"),
	 				new Formato(null, Color.GREEN, StyleBuilder.MARK_CIRCLE, Color.GRAY));
		
		
		Dados.lista.add(c);
		Dados.lista.add(c2);
		Dados.lista.add(c3);
		Dados.lista.add(c4);
		Dados.lista.add(c5);
		Dados.lista.add(c6);
		Dados.lista.add(c7);
		Dados.lista.add(c8);
		Dados.lista.add(c9);
		
		new JanelaPrincipal();
		
	}
}
