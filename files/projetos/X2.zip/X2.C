//O X da Questao 2
//por Paulo Collares

#include<conio.h>
#include<stdio.h>
#include<time.h>
#include<bios.h>
#include<dos.h>
#include <string.h>

struct slot{
		char nome[30];
		int fase;
		int reset;
		int modo;
		}registro[10];

char matriz [77] [39];
int x,y,
ctrl,
esq,dir,cim,bai,
fase,mov[21],
s,t,v,
px,py,
modo_jogo,
mov_max,
num_reset;

void main(){
textmode(C4350);
s=1;
menu_principal();
}

/*Fun�oes*/

menu_principal(){
int i,j;
nosound();
tela("Menu Principal");
zera_matriz();
//o
for(i=27;i<31;i++)
matriz [i] [6]=matriz [i] [10]='l';
for(i=6;i<10;i++)
matriz [27] [i]=matriz [30] [i]='l';
//x
matriz [34] [6]=matriz [35] [7]=matriz [36] [8]=matriz [37] [9]=matriz [38] [10]='l';
matriz [38] [6]=matriz [37] [7]=matriz [35] [9]=matriz [34] [10]='l';
//da
//d
for(i=42;i<45;i++)
matriz [i] [6]=matriz [i] [10]='l';
for(i=6;i<10;i++)
matriz [42] [i]='l';
for(i=7;i<10;i++)
matriz [45] [i]='l';
//a
for(i=6;i<11;i++)
matriz [47] [i]=matriz [50] [i]='l';
for(i=47;i<50;i++)
matriz [i] [6]=matriz [i] [9]='l';
//quest�o
//q
for(i=21;i<25;i++)
matriz [i] [16]=matriz [i] [20]='l';
for(i=16;i<20;i++)
matriz [21] [i]=matriz [24] [i]='l';
matriz [23] [21]='l';
//u
for(i=16;i<20;i++)
matriz [26] [i]=matriz [29] [i]='l';
for(i=26;i<30;i++)
matriz [i] [20]='l';
//e
for(i=16;i<21;i++)
matriz [31] [i]='l';
for(i=32;i<34;i++)
matriz [i] [16]=matriz [i] [20]='l';
matriz [32] [18]='l';
//s
for(i=35;i<38;i++)
matriz [i] [16]=matriz [i] [18]=matriz [i] [20]='l';
matriz [35] [17]=matriz [37] [19]='l';
//t
for(i=39;i<44;i++)
matriz [i] [16]='l';
for(i=16;i<21;i++)
matriz [41] [i]='l';
//~a
for(i=16;i<21;i++)
matriz [45] [i]=matriz [48] [i]='l';
for(i=46;i<48;i++)
matriz [i] [14]=matriz [i] [16]=matriz [i] [19]='l';
//o
for(i=51;i<54;i++)
matriz [i] [16]=matriz [i] [20]='l';
for(i=16;i<21;i++)
matriz [51] [i]=matriz [54] [i]='l';
//2
for(i=36;i<39;i++)
matriz [i] [25]=matriz [i] [27]=matriz [i] [29]='l';
matriz [38] [26]=matriz [36] [28]='l';

desenha_matriz(1);
cor(15,1);
gotoxy(3,5);
cprintf("DICA:");
gotoxy(4,6);
cprintf("Utilize as setas (%c e %c) para navegar no menu e [enter] para acessa-lo",27,26);
gotoxy(36,38);
cprintf("ver. 1.0");
cor(14,1);
gotoxy(3,44);
cprintf("Humilhai-vos debaixo da potente m�o de Deus para que AO SEU TEMPO vos exalte");
cor(15,1);
gotoxy(68,45);
cprintf("(I Pe. 5:6)");
ajuda2("Pressione Alt+Enter para jogar em tela cheia",225);
menu();
return 0;
}

cor(int t, int bg){
textcolor(t);
textbackground(bg);
return 0;
}

tela(char texto[50]){
int i,j,i2;

textcolor(14);
textbackground(1);
for (i=0;i<78;i++){
	gotoxy(2+i,1);
	cprintf("%c",205);
	gotoxy(2+i,4);
	cprintf("%c",205);
	gotoxy(2+i,49);
	cprintf("%c",205);
	gotoxy(2+i,46);
	cprintf("%c",205);
	}

for (i=0;i<48;i++){
	gotoxy(1,2+i);
	cprintf("%c",186);
	gotoxy(80,2+i);
	cprintf("%c",186);
	}

gotoxy(1,1);
cprintf("%c",201);
gotoxy(80,1);
cprintf("%c",187);
gotoxy(1,49);
cprintf("%c",200);
gotoxy(80,49);
cprintf("%c",188);
gotoxy(1,4);
cprintf("%c",204);
gotoxy(1,46);
cprintf("%c",204);
gotoxy(80,4);
cprintf("%c",185);
gotoxy(80,46);
cprintf("%c",185);

textcolor(15);
textbackground(1);
gotoxy(20,1);
cprintf(" O X da Quest�o 2 - by Paulo Collares ");

cor(0,3);
gotoxy(2,2);
for (i=0;i<78;i++) cprintf(" ");

gotoxy(2,2);
cprintf(" %s",texto);

cor(0,7);
gotoxy(2,3);
for (i=0;i<78;i++) cprintf(" ");

cor(0,7);
gotoxy(2,47);
for (i=0;i<78;i++) cprintf(" ");

cor(0,7);
gotoxy(2,48);
for (i=0;i<78;i++) cprintf(" ");
ajuda2("Por favor, aguarde...",0);
cor(0,1);
i2=41;
for (i=40;i>1;i--){
	for (j=5;j<=45;j++){
		gotoxy(i,j);
		cprintf(" ");
		gotoxy(i2,j);
		cprintf(" ");
					}
					i2++;
						}
cor(8,7);
gotoxy(3,3);
cprintf("Novo  Carregar  Salvar  Continuar  Reset  Ajuda  Sobre  Sair");
ajuda2(" ",0);

return 0;
}

menu(){
	switch (selecao()){
		 case 1: if (fase){
						if (continuar("iniciar um novo jogo")){
													menu_novo();
													return 0; } else{
															desenha_matriz(1);
															jogando();
															return 0; }
													} else
														menu_novo();
														return 0;
		 case 2:menu_carrega();
				  return 0;
		 case 3:menu_salva();
					return 0;
		 case 4: volta();
					return 0;
		 case 5: num_reset++;
					fase--;
					jogo();
					return 0;
		 case 6: ajuda_do_jogo(); return 0;
		 case 7: sobre(); return 0;
		 case 8: if (continuar("Sair")) return 0;
					else{
						 if (fase){
							volta();
									}else
							menu_principal();
						 return 0;
						 }
			  }
return 0;
}

selecao(){
char ctrl;
char op1[10]="Novo",op2[10]="Carregar",op3[10]="Salvar",op4[10]="Continuar",op5[10]="Reset",op6[10]="Ajuda",op7[10]="Sobre",op8[10]="Sair";
int pos;
if (fase) pos=4;
	else pos=1;
for(;;){
cor (0,7);
gotoxy(2,3);
cprintf(" %s  %s  %s  %s  %s  %s  %s  %s",op1,op2,op3,op4,op5,op6,op7,op8);
if (fase==0){
	cor(8,7);
	gotoxy(19,3);
	cprintf("%s  %s  %s",op3,op4,op5);
	}

	cor (14,1);
	switch(pos){
		case 1: gotoxy(3,3);
					cprintf(" %s",op1);
					ajuda("Novo - Inicia um novo jogo",0);
					break;
		case 2: gotoxy(9,3);
				  cprintf(" %s",op2);
				  ajuda("Carregar - Carrega um jogo salvo",0);
				  break;
		case 3: gotoxy(19,3);
					cprintf(" %s",op3);
					ajuda("Salvar - Salva o jogo atual",0);
					break;
		case 4: gotoxy(27,3);
					cprintf(" %s",op4);
					ajuda("Continuar - Continua jogando o jogo atual",0);
					break;
		case 5: gotoxy(38,3);
					cprintf(" %s",op5);
					 ajuda("Reset - Reenicia a fase atual",4);
					 break;
		case 6: gotoxy(45,3);
					cprintf(" %s",op6);
					ajuda("Ajuda - Instru��oes sobre o jogo",0);
					break;
		case 7: gotoxy(52,3);
					cprintf(" %s",op7);
					ajuda("Sobre - Informa��oes sobre o jogo",0);
					break;
		case 8: gotoxy(59,3);
					cprintf(" %s",op8);
					ajuda("Sair - Sai para o Windows",4);
					break;

	}
	gotoxy(80,50);
	ctrl=getch();
	cor (0,7);
	gotoxy(2,3);
	cprintf(" %s  %s  %s  %s  %s  %s  %s  %s  ",op1,op2,op3,op4,op5,op6,op7,op8);
	ajuda("",0);
	switch (ctrl){
		case 'K':pos--; break;
		case 'M':pos++; break;
		case 'p': if (fase) return 4; else break;
		case 27: return 8;

		case 13:switch (pos){
						case 1:return 1;
						case 2:return 2;
						case 3:return 3;
						case 4: return 4;
						case 5: return 5;
						case 6: return 6;
						case 7: return 7;
						case 8: return 8;
							}
		}
		if (pos==0) pos=8;
		if (pos==9) pos=1;
		if (fase==0){
			if (pos==3) pos=6;
			if (pos==5) pos=2;
				}
}
}

box_pass(){
char pass[30];

ajuda("Digite a password e pressione enter",0);
ajuda2("",0);
janela(30,10,50,12,"password");
gotoxy(31,11);
cor(0,7);
cprintf("                   ");
gotoxy(32,11);
scanf("%s",pass);

if (!(strcmp(pass,"allfases"))){
				if (menu_pass()) return 1;
				else
				return 0;
				}

	if (!(strcmp(pass,"zerareset"))){
				num_reset=0;
				desenha_matriz(1);
				ajuda_ctrl();
				return 0;
				}
	if (!(strcmp(pass,"nextfase"))){
				matriz [x] [y]='X';
				desenha_matriz(1);
				ajuda_ctrl();
				return 0;
				}
	if (!(strcmp(pass,"plusmov"))){
				mov[fase]++;
				desenha_matriz(1);
				ajuda_ctrl();
				return 0;
				}


gotoxy(32,11);
cor(224,7);
cprintf("Password inv�lida");
sleep(1);

desenha_matriz(1);
ajuda_ctrl();
return 0;
}


menu_pass(){
int i,posf=1,posm=1;
char ctrl;

tela("PassWord");
cor(14,1);
gotoxy(5,8);
cprintf("Escolha o modo do jogo com %c e %c e a fase com %c e %c",26,27,24,25);
cor(15,1);
gotoxy(14,14);
cprintf("Modo livre");
gotoxy(29,14);
cprintf("Jogo F�cil");
gotoxy(44,14);
cprintf("Jogo M�dio");
gotoxy(59,14);
cprintf("Jogo Dif�cil");

cor(14,1);
for (i=1;i<=20;i++){
	 gotoxy(15,15+i);
	 cprintf("Fase %d",i);
	 gotoxy(30,15+i);
	 cprintf("Fase %d",i);
	 gotoxy(45,15+i);
	 cprintf("Fase %d",i);
	 gotoxy(60,15+i);
	 cprintf("Fase %d",i);
	 }
	 cor(15,1);
	 gotoxy(10,40);
	 cprintf("Pressione enter para ir para o jogo e esc para voltar");
for(;;){
		if (posf==0) posf=20;
		if (posf==21) posf=1;
		if (posm==0) posm=4;
		if (posm==5) posm=1;
		switch(posm){
			case 1:ajuda("Modo livre: sem limites de movimentos",0); gotoxy(14,15+posf); break;
			case 2:ajuda("Modo com limites de movimentos, dificuldade: f�cil",0); gotoxy(29,15+posf); break;
			case 3:ajuda("Modo com limites de movimentos, dificuldade: m�dia",0);gotoxy(44,15+posf); break;
			case 4:ajuda("Modo com limites de movimentos, dificuldade: dif�cil",0);gotoxy(59,15+posf); break;
			  }
			  cor(15,1);
			  cprintf("%c",16);
			  cor(0,7);
			  gotoxy(35,48);
			  cprintf("Esta � a fase %d ",posf);

	gotoxy(80,50);

	ctrl=getch();

	switch(posm){
			case 1:gotoxy(14,15+posf); break;
			case 2:gotoxy(29,15+posf); break;
			case 3:gotoxy(44,15+posf); break;
			case 4:gotoxy(59,15+posf); break;
			  }
			  cor(15,1);
			  cprintf(" ");
	switch (ctrl){
		case 'H':posf--; break;
		case 'P':posf++; break;
		case 'K':posm--; break;
		case 'M':posm++; break;
		case 27:	return 0;
		case 13: fase=posf;
					modo_jogo=posm;
					return 1;
		}

}
}

ajuda(char str[72],int cor){
int i;

textbackground(7);

gotoxy(2,47);
for (i=0;i<78;i++)
	cprintf(" ");

textcolor(cor);
gotoxy(40-(strlen(str)/2),47);
cprintf("%s",str);
textcolor(7);
return 0;
}

ajuda2(char str[72],int cor){
int i;

textbackground(7);

gotoxy(2,48);
for (i=0;i<78;i++)
	cprintf(" ");

textcolor(cor);
gotoxy(40-(strlen(str)/2),48);
cprintf("%s",str);
textcolor(7);
return 0;
}

ajuda_do_jogo(){
tela("Como jogar 'O X da quest�o 2'");

gotoxy(3,7);
cor(14,1);
cprintf("O que � o X da quest�o");
cor(15,1);
gotoxy(5,9);
cprintf("O X da quest�o � um Jogo de l�gica e estrat�gia, onde o objetivo � achar");
gotoxy(4,10);
cprintf("um meio de chegar at� o X. Lembrando-se de que s� � possivel mudar a dire��o");
gotoxy(4,11);
cprintf("quando voc� estiver encostado em uma parede.");
cor(14,1);
gotoxy(3,13);
cprintf("Objetos especiais");
cor(15,1);
gotoxy(5,15);
cprintf("Novos objetos aparescer�o durante o jogo, e sua explica��o ira aparecer no");
gotoxy(4,16);
cprintf("inicio de cada fase.");
cor(14,1);
gotoxy(3,18);
cprintf("Controles");
cor(15,1);
gotoxy(5,20);
cprintf("Setas direcionais -> Movimenta��o");
gotoxy(5,21);
cprintf("r -> reset || m -> Mute || v -> Velocidade");
gotoxy(5,22);
cprintf("barra de espa�o -> destaca a localiza��o do face");
gotoxy(5,23);
cprintf("p ou esc -> pausa o jogo e acessa o menu");
cor(14,1);
gotoxy(3,25);
cprintf("Tipos de jogo");
cor(15,1);
gotoxy(5,27);
cprintf("No jogo livre voc� ira jogar sem limites de movimentos, j� no desafio do");
gotoxy(4,28);
cprintf("X da quest�o cada fase tem um limite m�ximo de movimentos, este n�mero varia");
gotoxy(4,29);
cprintf("de acordo com a dificuldade do jogo.");
cor(14,1);
gotoxy(3,31);
cprintf("Fim do jogo");
cor(15,1);
gotoxy(5,33);
cprintf("Quando voc� vencer todas as 20 fases do desafio do X da quest�o uma");
gotoxy(4,34);
cprintf("recompensa sera mostrada a voc�");

menu();
return 0;
}

sobre(){

tela("Sobre o X da quest�o 2");
cor (14,1);
gotoxy(4,7);
cprintf("O X da Quest�o 2");
cor(15,1);
gotoxy(4,8);
cprintf("================");
gotoxy(4,11);
cprintf("Vers�o 1.0 para windows");
gotoxy(4,13);
cprintf("Compilado no Turbo C 3.0");
gotoxy(4,15);
cprintf("Periodo de constru��o: 22/03/2007 - 25/05/2007");
gotoxy(4,17);
cprintf("Por Paulo Collares Moreira Neto");
menu();
return 0;
}

continuar(char texto[10]){
char ctrl='K';
int pos=1;

janela (25,19,55,26,"");
gotoxy(30,21);
cor(4,7);
cprintf("Tem certeza que deseja");
gotoxy(40-(strlen(texto)/2),22);
cprintf("%s?",texto);

for(;;){
if (pos==1){
	cor(14,1);
	gotoxy(32,24);
	cprintf(" Sim ");
	cor(0,7);
	gotoxy(43,24);
	cprintf(" N�o ");
		}
if (pos==2){
	cor(0,7);
	gotoxy(32,24);
	cprintf(" Sim ");
	cor(14,1);
	gotoxy(43,24);
	cprintf(" N�o ");
		}
ctrl=getch();
switch(ctrl){
	case 'K': pos=1; break;
	case 'M': pos=2; break;
	case 13: if (pos==1) return 1;
				if (pos==2) return 0;
	}

}
}

janela(int xt, int yt, int xb, int yb, char titulo[15]){
int i,j;

if (!strcmp(titulo,"apagar")){
		textbackground(1);
for (i=xt;i<xb+2;i++){
	for (j=yt;j<yb+2;j++){
		gotoxy(i,j);
		cprintf(" ");
		}}
		return 0;
		}
textbackground(7);
for (i=xt;i<xb;i++){
	for (j=yt;j<yb;j++){
		gotoxy(i,j);
		cprintf(" ");
		}}

cor(15,7);
gotoxy(xt,yt);
cprintf("%c",218);
gotoxy(xb,yt);
cprintf("%c",191);
gotoxy(xt,yb);
cprintf("%c",192);
for (i=1;i<(xb-xt);i++){
	gotoxy(xt+i,yt);
	cprintf("%c",196);
	}
for (i=1;i<(yb-yt);i++){
	gotoxy(xt,yt+i);
	cprintf("%c",179);
	}

textcolor(0);
gotoxy(xb,yb);
cprintf("%c",217);
for (i=1;i<(xb-xt);i++){
	cor(0,7);
	gotoxy(xt+i,yb);
	cprintf("%c",196);
	cor(0,0);
	gotoxy(xt+i,yb+1);
	cprintf("   ");
		}
for (i=1;i<(yb-yt);i++){
	cor(0,7);
	gotoxy(xb,yt+i);
	cprintf("%c",179);
	cor(0,0);
	gotoxy(xb+1,yt+i);
	cprintf(" ");
	}
gotoxy(xb+1,yb);
cprintf(" ");
cor(0,7);
gotoxy(( ((xt+xb)/2) - (strlen(titulo)/2)),yt);
cprintf("%s",titulo);
return 0;
}

menu_novo(){
char op1[30]="Jogue o X da Quest�o",op2[30]="Modo Livre",op3[30]="Cancelar";
char ctrl;
int pos=1;
fase=0;
tela("Novo Jogo");

ajuda2("Pressione esc para voltar",0);
cor(7,1);
gotoxy(10,10);
cprintf("Escolha um jogo");

for(;;){
cor (7,1);
gotoxy(30,12);
cprintf("%s ",op1);
gotoxy(30,13);
cprintf("%s ",op2);
gotoxy(30,14);
cprintf("%s ",op3);

	janela(20,20,60,28,"Descri��o");
	cor (14,0);
	switch(pos){
		case 1: gotoxy(30,12); cprintf(" %s",op1);
					gotoxy(22,21); cor(1,7); cprintf("Desafio do X da quest�o:");
					gotoxy(23,23); cor(0,7); cprintf("Complete as fases");
					gotoxy(23,24); cprintf("com limite de movimento");
					gotoxy(23,25); cprintf("Um novo desafio a cada etapa");
					break;
		case 2: gotoxy(30,13); cprintf(" %s",op2);
					gotoxy(22,21); cor(1,7); cprintf("Jogo Livre do X da quest�o:");
					gotoxy(23,23); cor(0,7); cprintf("Jogue sem o limite de movimentos");
					gotoxy(23,24); cprintf("Treine aqui e depois tente o jogo");
					gotoxy(23,25); cprintf("acima");
					break;
		case 3: gotoxy(30,14); cprintf(" %s",op3);
					gotoxy(22,21); cor(1,7); cprintf("Cancele");
					gotoxy(23,23); cor(0,7); cprintf("Volta para o menu principal");

					break;
				}

	ctrl=getch();
	switch (ctrl){
		case 'H':pos--; break;
		case 'P':pos++; break;
		case 27:menu_principal(); return 0;
		case 13:switch (pos){
						case 1: dificuldade(); return 0;
						case 2: modo_jogo=1; num_reset=0; jogo(); return 0;
						case 3: menu_principal(); return 0;
							}
		}
		if (pos==0) pos=3;
		if (pos==4) pos=1;
}
}
dificuldade(){
char op1[30]="F�cil",op2[30]="Medio",op3[30]="Dificil";
char ctrl;
int pos=2;
fase=0;
tela("Dificuldade");

ajuda2("Pressione esc para voltar",0);
cor(7,1);
gotoxy(10,10);
cprintf("Escolha uma dificuldade");

for(;;){
cor (7,1);
gotoxy(30,12);
cprintf("%s ",op1);
gotoxy(30,13);
cprintf("%s ",op2);
gotoxy(30,14);
cprintf("%s ",op3);

	janela(20,20,60,28,"Descri��o");
	cor (14,0);
	switch(pos){
		case 1: gotoxy(30,12); cprintf(" %s",op1);
					gotoxy(22,21); cor(1,7); cprintf("Desafio do X da quest�o:");
					gotoxy(23,23); cor(0,7); cprintf("F�cil");
					gotoxy(23,24); cprintf("Para cada fase voc� ter� 100% a");
					gotoxy(23,25); cprintf("mais de movimentos para usar");
					break;
		case 2: gotoxy(30,13); cprintf(" %s",op2);
					gotoxy(22,21); cor(1,7); cprintf("Desafio do X da quest�o:");
					gotoxy(23,23); cor(0,7); cprintf("Medio");
					gotoxy(23,24); cprintf("Para cada fase voc� ter� 50% a");
					gotoxy(23,25); cprintf("mais de movimentos para usar");
					break;
		case 3: gotoxy(30,14); cprintf(" %s",op3);
					gotoxy(22,21); cor(1,7); cprintf("Desafio do X da quest�o:");
					gotoxy(23,23); cor(0,7); cprintf("Dificil");
					gotoxy(23,24); cprintf("Voc� n�o ter� nenhum movimento");
					gotoxy(23,25); cprintf("a mais para usar");

					break;
				}

	ctrl=getch();
	switch (ctrl){
		case 'H':pos--; break;
		case 'P':pos++; break;
		case 27:menu_novo(); return 0;
		case 13:switch (pos){
						case 1: modo_jogo=2; num_reset=0; jogo(); return 0;
						case 2: modo_jogo=3; num_reset=0; jogo(); return 0;
						case 3:  modo_jogo=4; num_reset=0; jogo(); return 0;
							}
		}
		if (pos==0) pos=3;
		if (pos==4) pos=1;
}
}

jogo(){
v=1;
t=50;
fase++;
gotoxy(57,5);
cor(1,7);
cprintf("Coord.: ");
cor(0,7);
cprintf("(x,y)    ");
reset_novo();
ajuda_ctrl();
jogando();
return 0;
}

jogando(){
for(;;){
sound(s*400);
delay(t);
nosound();
gotoxy(57,5);
cor(1,7);
cprintf("Coord.: ");
cor(0,7);
cprintf("(%d,%d)  ",x,y);

if (bioskey(1))
		if(controles(0)){
				menu();
				return 0;}

matriz [x] [y]=1;
desenha_matriz(0);
matriz [x] [y]=' ';
x=x+dir-esq;
y=y+bai-cim;
if (stop()){
		if (!mov_zero())
		if (controles(1)){
					menu();
					return 0;
					}
				}
if (especiais()){
				menu_principal();
				return 0;
				}
}
}

estatisticas(){
int i;
cor(0,7);
gotoxy(2,5);
for(i=0;i<55;i++)
	cprintf(" ");

gotoxy(5,5);
textcolor(0);
cprintf("%d",mov[fase]);
textcolor(1);
cprintf(" movimentos");

	if ((modo_jogo>=2)&&(mov[fase]<=1)){
									gotoxy(5,5);
									textcolor(228);
									cprintf("%d movimento!",mov[fase]);
									}
gotoxy(22,5);
cor(1,7);
cprintf("Reset:");
cor(0,7);
cprintf(" %d",num_reset);
gotoxy(75,5);

gotoxy(35,5);
textcolor(1);
cprintf("Velocidade(v): ");
textbackground(0);
cprintf("    ");
gotoxy(50,5);
switch(v){
	case 1:textbackground(2); cprintf(" "); break;
	case 2:textbackground(1); cprintf("  "); break;
	case 3:textbackground(6); cprintf("   ");break;
	case 4:textbackground(4); cprintf("    ");break;
	}
gotoxy(74,5);
cor(4,7);
	if (!s)
		cprintf(" MUTE ");
	else
		cprintf("      ");
gotoxy(80,50);
return 0;
}

stop(){
if (matriz [x] [y]=='p' && cim!=0){
y++;
return 1;}
if (matriz [x] [y]=='p' && bai!=0){
y--;
return 1;}
if (matriz [x] [y]=='p' && dir!=0){
x--;
return 1;}
if (matriz [x] [y]=='p' && esq!=0){
x++;
return 1;}
return 0;
}

controles(int modo){
char p;
ctrl=getch();
if (modo){
switch(ctrl){
case 'K':cim=bai=dir=0;
	esq=1;
	if (matriz [x-1] [y]!='p')
	switch(modo_jogo){
		case 1: mov[fase]++; break;
		case 2:
		case 3:
		case 4: mov[fase]--; break;
		}
	break;
case 'M':esq=cim=bai=0;
	dir=1;
	if (matriz [x+1] [y]!='p')
		switch(modo_jogo){
		case 1: mov[fase]++; break;
		case 2:
		case 3:
		case 4: mov[fase]--; break;
		}
	break;
case 'H':esq=bai=dir=0;
	cim=1;
	if (matriz [x] [y-1]!='p')
		switch(modo_jogo){
		case 1: mov[fase]++; break;
		case 2:
		case 3:
		case 4: mov[fase]--; break;

		}
	break;
case 'P':esq=dir=cim=0;
	bai=1;
	if (matriz [x] [y+1]!='p')
		switch(modo_jogo){
		case 1: mov[fase]++; break;
		case 2:
		case 3:
		case 4: mov[fase]--; break;
		}
	break;
default: break;
	}
}
switch(ctrl){
case 'p':
case 27: janela(23,20,58,28,"");
			gotoxy(35,22);
			cor(228,7);
			cprintf("Jogo em Pausa");
			gotoxy(25,24);
			cor(0,7);
			cprintf("Pressione p ou continuar no menu");
			gotoxy(35,26);
			cor(228,7);
			cprintf("Jogo em Pausa");
			ajuda2("Jogo em pausa",0);
			return 1;
case 'm':if (s==1)s=0; else s=1;
	break;
case 16: /*alt+q*/
		if (box_pass())
						 reset_novo();
		break;
case'r':
	num_reset++;
	reset_novo();
	break;
case 'v': v++; if (v==5) v=1;
	switch(v){
	case 1: t=50; break;
	case 2: t=30; break;
	case 3: t=10; break;
	case 4: t=0; break;
	}
	break;
case ' ':gotoxy(2+x,6+y);
			cor(228,2);
			cprintf("%c",1);
			cor(225,2);
			gotoxy(2+x,6+y+1);
			cprintf("%c",24);
			gotoxy(2+x,6+y-1);
			cprintf("%c",25);
			gotoxy(2+x-1,6+y);
			cprintf("%c",26);
			gotoxy(2+x+1,6+y);
			cprintf("%c",27);
			gotoxy(80,50);
			sleep(1);
			break;
default: break;
	  }
	  estatisticas();
	  return 0;
	  }

zera_matriz(){
int i,j;
for (i=0;i<=77;i++){
for (j=0;j<=39;j++){
matriz [i] [j]=' ';
}}return 0;}

monta_borda(){
int i;

for (i=0;i<=77;i++)
	matriz [i] [0]=matriz [i] [39]='p';
for (i=0;i<=39;i++)
	matriz [0] [i]=matriz [77] [i]='p';
return 0;
}

desenha_matriz(int modo){
int i,j,i2,inix,iniy,fimx,fimy;

switch(modo){
case 0:
	inix=x-1;
	iniy=y-1;
	fimx=x+1;
	fimy=y+1;

	if (inix<0) inix=0;
	if (iniy<0) iniy=0;
	if (fimx>77) fimx=77;
	if (fimy>39) fimy=39;

	for (i=inix;i<=fimx;i++){
		for (j=iniy;j<=fimy;j++){
			estrutura(i,j);
									}
							}
		 break;
case 1:
			i2=77;
			for (i=0;i<=40;i++){
			for (j=0;j<=39;j++){
			estrutura(i,j);
			estrutura(i2,j);
			}
			i2--;
			}
		break;
case 2:
	inix=x-2;
	iniy=y-2;
	fimx=x+2;
	fimy=y+2;

	if (inix<0) inix=0;
	if (iniy<0) iniy=0;
	if (fimx>77) fimx=77;
	if (fimy>39) fimy=39;

	for (i=inix;i<=fimx;i++){
		for (j=iniy;j<=fimy;j++){
			estrutura(i,j);
									}
							}
		 break;
		 }
gotoxy(80,50);
return 0;
}

estrutura(int i, int j){
if(fase) cor(0,2);
		else cor(0,1);
		gotoxy(2+i,6+j);
		switch (matriz [i] [j]){
			case 'l':cor(7,1);
						cprintf("%c",178);
						break;
			case 1: textcolor(1);
						cprintf("%c",1);
						break;
			case 2: textcolor(1);
						cprintf("%c",2);
						break;
			case 'p':cor(0,2);
						cprintf("%c",177);
						break;
			case 'X':textcolor(4);
						cprintf("X");
						break;
			case 'E': textcolor(15);
						cprintf("E");
						break;
			case 'S': textcolor(15);
						cprintf("S");
						break;
			case 'a':cor(7,1);
						cprintf(" ");
						break;
			case 24:
			case 25:
			case 26:
			case 27: textcolor(6);
						cprintf("%c",matriz [i] [j]);
						break;
			case 21: textcolor(9);
						cprintf("%c",21);
						break;
			case 16:
			case 17: textcolor(6);
						cprintf("%c",matriz [i] [j]);
						break;
			default:	cprintf("%c",matriz [i] [j]);
						break;
								}
if ((px>0)&&(matriz [px] [py]=='p')){
	cor(0,2);
	gotoxy(2+px,6+py);
	cprintf("%c",178);
		}
return 0;
}

reset_novo(){
char nome_fase[30];

mov[fase]=0;
px=py=0;
zera_matriz();
monta_borda();
load_fase();
switch (modo_jogo){
case 1:break;
case 2: mov_max=mov_max+(mov_max);
			mov[fase]=mov_max;
			break;
case 3:  mov_max=mov_max+(mov_max/2);
			mov[fase]=mov_max;
			break;
case 4: 	mov[fase]=mov_max;
			break;

						}
matriz [x] [y]=1;
desenha_matriz(1);
estatisticas();
delay(100);
janela(8,9,71,25,"Nova Fase");

switch(fase){
	case 1:  strcpy(nome_fase,"O inicio");
				cor(1,7);
				gotoxy(12,13);
				cprintf("Use as setas direcionais para guiar o 'Face'(%c) at� o X.",1);
				gotoxy(12,14);
				cprintf("Lembre-se que voc� s� pode mudar de dire��o quando estiver");
				gotoxy(12,15);
				cprintf("encostado em uma perede.");
				break;
	case 2: strcpy(nome_fase,"Estreito");
				break;
	case 3: strcpy(nome_fase,"Descendo...");
				break;
	case 4: strcpy(nome_fase,"Uma luz no buraco negro");
			  cor(1,7);
			  gotoxy(12,13);
			  cprintf("NOVO OBJETO: Buraco Negro");
			  gotoxy(12,14);
			  cprintf("Use a entrada (E) para usar o buraco negro e sair em (S).");
				break;
	case 5: strcpy(nome_fase,"Deixa me levar");
				break;
	case 6: strcpy(nome_fase,"Empurrando paredes");
			  cor(1,7);
			  gotoxy(12,13);
			  cprintf("NOVO OBJETO: P�");
			  gotoxy(12,14);
			  cprintf("Passando por cima da p� (%c %c %c %c) a parede",24,25,26,27);
			  gotoxy(12,15);
			  cprintf("para onde ela aponta se mover�");
			  break;
	case 7: strcpy(nome_fase,"Movendo tudo");
			  break;
	case 8: strcpy(nome_fase,"Abrindo a porta");
				cor(1,7);
			  gotoxy(12,13);
			  cprintf("NOVO OBJETO: Chave e Porta");
			  gotoxy(12,14);
			  cprintf("Use a chave (%c) para abrir a porta (%c)",21,178);
			  break;
	case 9: strcpy(nome_fase,"Mini Labirinto");
				break;
	case 10: strcpy(nome_fase,"O encanamento");
				break;
	case 11: strcpy(nome_fase,"T� Perdido");
			break;
	case 12: strcpy(nome_fase,"Construindo paredes");
				cor(1,7);
			  gotoxy(12,13);
			  cprintf("NOVO OBJETO: Construtor de Paredes");
			  gotoxy(12,14);
			  cprintf("Passe por cima de uma das chaves (%cou%c) para construir",16,17);
			  gotoxy(12,15);
			  cprintf("ou desconstruir uma parede entre elas");
				break;
	case 13: strcpy(nome_fase,"Tubos");
				break;
	case 14: strcpy(nome_fase,"Afogando-se");
				cor(1,7);
			  gotoxy(12,13);
			  cprintf("NOVO OBJETO: �gua");
			  gotoxy(12,14);
			  cprintf("Se voc� passar pela �gua (");
			  cor(1,1); cprintf(" ");
			  cor(1,7);
			  cprintf(") ir� se afogar");
			  gotoxy(12,15);
			  cprintf("e a fase ser� reeniciada");
				break;
	case 15: strcpy(nome_fase,"As Ilhas e as pontes");
				break;
	case 16: strcpy(nome_fase,"O cerco");
				break;
	case 17: strcpy(nome_fase,"A ilha");
				break;
	case 18: strcpy(nome_fase,"S� paredes");
				break;
	case 19: strcpy(nome_fase,"A piscina");
				break;
	case 20: strcpy(nome_fase,"O desafio final");
				break;
	default:	zerou();
				return 1;
			  }

gotoxy(3,2);
cor(0,3);
cprintf("Fase");
cor(4,3);
cprintf(" %d",fase);
cor(0,3);
cprintf(" de");
cor(4,3);
cprintf(" 20");
cor(1,3);
cprintf(" - %s               ",nome_fase);

cor(0,7);
gotoxy(10,11);
cprintf("Fase %d: %s",fase,nome_fase);

cor(0,7);
gotoxy(10,19);
cprintf("Tipo do Jogo:");
cor(1,7);
gotoxy(12,20);
switch(modo_jogo){
	case 1: cprintf("Jogo livre"); break;
	case 2:
	case 3:
	case 4:  cprintf("Jogo com limite de movimentos");
				gotoxy(12,21);
				cprintf("Dificuldade: ");
				cor(0,7);
				switch(modo_jogo){
						case 2: cprintf("F�cil"); break;
						case 3: cprintf("M�dio"); break;
						case 4: cprintf("Dificil"); break;
						}
				cor(1,7);
				gotoxy(12,22);
				cprintf("Para esta fase voc� ter� um limite de ");
				cor(0,7);
				cprintf("%d",mov_max);
				cor(1,7);
				cprintf(" movimentos.");
				break;
	}
ajuda("Pressione [ENTER] para iniciar o jogo",224);
ajuda2("Boa Sorte :)",0);
gotoxy(80,50);
enter();
ajuda_ctrl();
desenha_matriz(1);
return 0;
}


zerou(){
int i,j,k;
float m;
m=0;
for (i=1;i<fase;i++) m=m+mov[i];
m=m/(fase-1);

tela("Fim do jogo");
cor(3,1);
janela(15,25,65,35,"estatisticas");
cor(0,7);
gotoxy(17,27);
cprintf("Voc� zerou no modo ");
cor(1,7);
switch(modo_jogo){
	case 1: cprintf("livre"); break;
	case 2: cprintf("com limite de movimentos");
				gotoxy(36,28);
				cprintf("na dificuldade f�cil"); break;
	case 3: cprintf("com limite de movimentos");
				gotoxy(36,28);
				cprintf("na dificuldade m�dia"); break;
	case 4: cprintf("com limite de movimentos");
				gotoxy(36,28);
				cprintf("na dificuldade dif�cil"); break;
	}
gotoxy(17,28);
cor(4,7);
if (modo_jogo==1) cprintf("Com uma media de %g movimentos por fase",m);
cor(1,7);
gotoxy(17,29);
if (num_reset){
	if (num_reset>1)
	cprintf("Durante o jogo voc� usou o reset %d vezes",num_reset);
	  else{
			cprintf("Parab�ns: Durante o jogo voc� usou o ");
			gotoxy(17,30);
			cprintf("reset uma �nica vez!");
			}
			}else{
			cprintf("PERFEITO! Voce n�o usou o reset");
			gotoxy(27,30);
			cprintf("nenhuma vez durante o jogo");
			}
ajuda("Pressione qualquer tecla",225);
ajuda2("para continuar",225);
cor(0,1);

for(i=15;i<=65;i++){
		cor(0,2);
		gotoxy(i,13);
		cprintf("%c",177);
		gotoxy(i,23);
		cprintf("%c",177);
		}
for(i=13;i<=23;i++){
		cor(0,2);
		gotoxy(15,i);
		cprintf("%c",177);
		gotoxy(65,i);
		cprintf("%c",177);
		}
cor(2,2);
for(i=16;i<=64;i++){
	for(j=14;j<=22;j++){
			gotoxy(i,j);
			cprintf(" ");
			}}
cor(7,1);
gotoxy(11,38);
cprintf("Cr�ditos:");
cor(14,1);
gotoxy(13,39);
cprintf("Cria��o.................................Paulo Collares");
gotoxy(13,40);
cprintf("Desenhos................................Paulo Collares");
gotoxy(13,41);
cprintf("Gr�ficos 2D.............................Paulo Collares");
gotoxy(13,42);
cprintf("Arte....................................Paulo Collares");
gotoxy(13,43);
cprintf("Som.....................................Paulo Collares");
gotoxy(13,44);
cprintf("Dire��o.................................Paulo Collares");

j=0; k=20;
for(;;){
nosound();
textbackground(1);
gotoxy(23,8);
textcolor(j);
cprintf("Parab�ns,");
gotoxy(30,9);
textcolor(k);
cprintf("Voc� Zerou ");
gotoxy(38,10);
textcolor(j+k);
cprintf("O X DA QUEST�O 2");
cor(1,2);
if (j<20){
sound(s*400);
gotoxy(63-j,22);
cprintf("%c",1);
}else{
gotoxy(44,22);
cprintf("%c",1);
if (j==25){
	gotoxy(45,21);
	cprintf("/");
	}
if (j==30){
	gotoxy(46,20);
	cprintf("valeu!");
	}
}
cor(3,1);
for (i=0;i<=40;i++){
		gotoxy(2,5+i);
		cprintf("Parab�ns");
		gotoxy(72,5+i);
		cprintf("Parab�ns");
		}
j++;
k++;
cor(4,1);
gotoxy(2,5+j);
cprintf("Parab�ns");
gotoxy(72,5+j);
cprintf("Parab�ns");
cor(7,1);
gotoxy(2,5+k);
cprintf("Parab�ns");
gotoxy(72,5+k);
cprintf("Parab�ns");

cor(2,2);
gotoxy(63-j+2,22);
cprintf(" ");
if (j==40){
			 for(i=16;i<=64;i++){
			for(j=14;j<=22;j++){
			gotoxy(i,j);
			cprintf(" ");
			}}
			 j=0;
			 }
if (k==40) k=0;
if (bioskey(1)){
				 ctrl=getch();
				 break;
					 }

gotoxy(80,50);
delay(100);

}
if (modo_jogo==1) return 0;
nosound();
tela("Bonus");
cor(14,1);
gotoxy(10,10);
cprintf("BONUS ESPECIAL");
cor(15,1);
gotoxy(15,12);
cprintf("Por ter zerado o X da quest�o 2 voc� agora tem acesso");
gotoxy(14,13);
cprintf("a estas senhas secretas");
gotoxy(14,15);
cprintf("Como fazer:");
cor(14,1);
gotoxy(17,17);
cprintf("%c Pressione alt+q DURANTE O JOGO",248);
gotoxy(17,18);
cprintf("%c Digite uma password:",248);
cor(15,1);
gotoxy(14,20);
cprintf("zerareset................Zera o contador de reset");
gotoxy(14,22);
cprintf("plusmov..................Acrescenta um movimento");
gotoxy(14,24);
cprintf("nextfase.................Pula para a pr�xima fase");
gotoxy(14,26);
cprintf("allfases.................Abre um menu com todas as fases em");
gotoxy(39,27);
cprintf("todos os modo para voc� escolher");

cor(14,1);
gotoxy(15,30);
cprintf("Pressione enter para continuar");
enter();
textcolor(7);
fase=0;
return 0;
	}

buraco(){
int i,j;
for (i=0;i<=77;i++){
for (j=0;j<=39;j++){
if (matriz [i] [j]=='S'){
	sound(s*300); delay(50);
	sound(s*310); delay(50);
	sound(s*320); delay(50);
	matriz [i] [j]=1;
	matriz [x] [y]=' ';
	desenha_matriz(0);
	x=i;
	y=j;
	desenha_matriz(0);
	sound(s*340); delay(50);
	sound(s*350); delay(50);
	sound(s*360); delay(60);
	nosound();
	return 0;
	}}}return 0;}

especiais(){
int i,j;
nosound();
if (matriz [x] [y]==21){
	sound(s*600); delay(100);
	gotoxy(px+2,py+6);
	cor(0,2);
	cprintf("%c",176);
	gotoxy(80,25);
	sound(s*650); delay(120);
	matriz[px] [py]=' ';
	px=py=0;
	delay(90);
	desenha_matriz(1);
	}

if (matriz [x] [y]=='E') buraco();

if (matriz [x] [y]==24){
	sound(s*400);
	delay(100);
	if (matriz [x] [y-1]=='p'){
	sound(s*450);
	delay(50);
	nosound();
	matriz [x] [y-1]=' ';
	matriz [x] [y-2]='p';
	desenha_matriz(2);
	sound(s*500);
	delay(100);
	nosound();}}
if (matriz [x] [y]==25){
	sound(s*400);
	delay(100);
	if (matriz [x] [y+1]=='p'){
	sound(s*450);
	delay(50);
	matriz [x] [y+1]=' ';
	matriz [x] [y+2]='p';
	desenha_matriz(2);
	sound(s*500);
	delay(100);
	nosound();}}
if (matriz [x] [y]==26){
	sound(s*400);
	delay(100);
	if (matriz [x+1] [y]=='p'){
	sound(s*450);
	delay(50);
	nosound();
	matriz [x+1] [y]=' ';
	matriz [x+2] [y]='p';
	desenha_matriz(2);
	sound(s*500);
	delay(100);
	nosound();}}
if (matriz [x] [y]==27){
	if (matriz [x-1] [y]=='p'){
	sound(s*450);
	delay(50);
	nosound();
	matriz [x-1] [y]=' ';
	matriz [x-2] [y]='p';
	desenha_matriz(2);
	sound(s*500);
	delay(100);
	nosound();
	}}

if (matriz [x] [y]==16){
int p;
for(i=1;i<=76;i++)
	if (matriz [i] [y]==17){
						p=i;
				if (matriz [x+1] [y]==' '){
							for(j=x+1;j<=i-(i-x)/2;j++){
									p--;
									delay(10);
									sound(s*250+j);
									matriz [j] [y]='p';
									gotoxy(2+j,6+y);
									cor(0,2);
									cprintf("%c",177);
									matriz [p] [y]='p';
									gotoxy(2+p,6+y);
									cprintf("%c",177);
									gotoxy(80,50);
													}
													} else
							 for(j=x+1;j<=i-(i-x)/2;j++){
									p--;
									delay(10);
									sound(s*300-j);
									matriz [j] [y]=' ';
									gotoxy(2+j,6+y);
									cor(0,2);
									cprintf(" ");
									matriz [p] [y]=' ';
									gotoxy(2+p,6+y);
									cprintf(" ");
									gotoxy(80,50);
													}
													 }
matriz [x] [y]=16;
if (bai==1) y++;
if (cim==1) y--;
desenha_matriz(2);
}

if (matriz [x] [y]==17){
int p;
for(i=1;i<=76;i++)
	if (matriz [i] [y]==16){
						p=x;
				if (matriz [x-1] [y]==' '){
							for(j=i+1;j<=x-(x-i)/2;j++){
									p--;
									delay(10);
									sound(s*250+j);
									matriz [j] [y]='p';
									gotoxy(2+j,6+y);
									cor(0,2);
									cprintf("%c",177);
									matriz [p] [y]='p';
									gotoxy(2+p,6+y);
									cprintf("%c",177);
									gotoxy(80,50);
													}
													} else
							 for(j=i+1;j<=x-(x-i)/2;j++){
									p--;
									delay(10);
									sound(s*300-j);
									matriz [j] [y]=' ';
									gotoxy(2+j,6+y);
									cor(0,2);
									cprintf(" ");
									matriz [p] [y]=' ';
									gotoxy(2+p,6+y);
									cprintf(" ");
									gotoxy(80,50);
													}
													 }
matriz [x] [y]=17;
if (bai==1) y++;
if (cim==1) y--;
desenha_matriz(2);
}
if (matriz [x] [y]=='a'){
		desenha_matriz(1);
		gotoxy(2+x,6+y);
		cor(7,1);
		cprintf("%c",1);
		gotoxy(80,25);
		sound(s*200);
		delay(200);
		sound(s*150);
		delay(300);
		num_reset++;
		reset_novo();
		}

if (matriz [x] [y]=='X'){
	matriz [x] [y]=2;
	desenha_matriz(0);
	sound(s*800); delay(100);
	matriz [x] [y]=1;
	desenha_matriz(0);
	sound(s*850); delay(100);
	matriz [x] [y]=2;
	desenha_matriz(0);
	sound(s*900); delay(380);
	matriz [x] [y]=1;
	desenha_matriz(0);
	sound(s*850); delay(130);
	matriz [x] [y]=2;
	desenha_matriz(0);
	sound(s*900); delay(580);

	nosound();
	janela(20,20,55,28,"X encontrado");
	cor(6,7);
	gotoxy(30,22);
	cprintf("%d%c Fase Conclu�da!",fase,167);
	gotoxy(30,24);
	if (modo_jogo==1)
		cprintf("com %d movimentos",mov[fase]);
			else
				cprintf("faltando %d movimentos",mov[fase]);
	cor(0,7);
	gotoxy(22,27);
	cprintf("Pressione [ENTER] para continuar");
	enter();
	fase++;
	if (reset_novo()) return 1;
	return 0;
		}
return 0;
}

mov_zero(){
if ((modo_jogo>=2)&&(mov[fase]==0)){
	num_reset++;
	janela(20,23,56,29,"Tente novamente");
	cor(4,7);
	gotoxy(22,25);
	cprintf("!Seus movimentos chegaram a ZERO!");
	gotoxy(22,27);
	cprintf("Pressione [ENTER] e tente de novo");
	sound(s*400); delay(300);
	sound(s*390); delay(300);
	sound(s*350); delay(500);
	nosound();
	enter();
	reset_novo();
	return 1;
	}
	return 0;
	}

enter(){
char ctrl;
do{
gotoxy(80,50);
ctrl=getch();
}while(ctrl!=13);
return 0;
}

paredev(int x,int ini, int fim){
int i;

for (i=0;i<=(fim-ini);i++)
	matriz [x] [ini+i]='p';
return 0;
}

paredeh(int y,int ini, int fim){
int i;

for (i=0;i<=(fim-ini);i++)
	matriz [ini+i] [y]='p';
return 0;
}

mar(int xini,int yini,int xfim,int yfim){
int i,j;

for(i=xini;i<=xfim;i++)
	for(j=yini;j<=yfim;j++)
		matriz [i] [j]='a';
return 0;
}

menu_carrega(){
int i,pos=1;
char ctrl;
carrega();
tela("Carregando um jogo salvo");
ajuda2("Pressione esc para acessar o menu",1);
cor(14,1);
gotoxy(5,7);
cprintf("Escolha um jogo");
for(;;){
cor(15,1);
for(i=1;i<=10;i++){
	gotoxy(10,10+i);
	if (registro[i].fase==0){
		cor(15,1);
		cprintf("Vazio                                             ");

			}
			else{
	cor(14,1);
	cprintf("%s | Fase: %d | Reset: %d",registro[i].nome,registro[i].fase,registro[i].reset);
	switch (registro[i].modo){
			case 1: cprintf(" | Modo livre"); break;
			case 2: cprintf(" | Modo Mov. F�cil"); break;
			case 3: cprintf(" | Modo Mov. M�dio"); break;
			case 4: cprintf(" | Modo Mov. Dif�cil"); break;
			}
	}
	}
cor(14,1);
gotoxy(10,21);
cprintf("CANCELAR");
gotoxy(10,22);
cprintf("APAGAR DADOS");

cor(1,15);
gotoxy(10,10+pos);
if (pos==12){
	cprintf("APAGAR DADOS");
	ajuda("Este comando apaga TODOS os jogos salvos",4);
		}else
if (pos==11){
			cprintf("CANCELAR");
			 ajuda("Volta",0);
			  }else
if (registro[pos].fase==0){
	cprintf("Vazio");
	ajuda("Este slot est� vazio",0);
				}else{
					cprintf("%s | Fase: %d | Reset: %d",registro[pos].nome,registro[pos].fase,registro[pos].reset);
						 switch (registro[pos].modo){
							case 1: cprintf(" | Modo livre"); break;
							case 2: cprintf(" | Modo Mov. F�cil"); break;
							case 3: cprintf(" | Modo Mov. M�dio"); break;
							case 4: cprintf(" | Modo Mov. Dif�cil"); break;
										}
						 ajuda("Pressione enter para carregar este jogo",0);
								}
gotoxy(80,25);
ctrl=getch();
switch(ctrl){
	case 'H': pos--; break;
	case 'P': pos++; break;
	case 27: menu(); return 0;
	case 13: switch(pos){
				case 11: if (fase){
									volta();
									return 0;
									  }else{
									  menu_principal();
									  return 0;
									  }
				case 12: if (continuar("apagar TODOS os jogos salvos")){
											for(i=1;i<=10;i++)
													registro[i].fase=0;
											salva();
											}
											janela (25,19,55,26,"apagar");

							break;
				default: if (registro[pos].fase!=0){
							  fase=registro[pos].fase;
							  num_reset=registro[pos].reset;
							  modo_jogo=registro[pos].modo;
							  fase--;
							  jogo();
							  return 0;
														}

							break;
							}
	}
if (pos==13) pos=1;
if (pos==0) pos=12;
}

}

menu_salva(){
int i,pos=1;
char ctrl;
carrega();
tela("Salvando o jogo");
ajuda2("Pressione esc para acessar o menu",1);
cor(14,1);
gotoxy(5,7);
cprintf("Escolha um slot vazio para gravar seu jogo");
cor(15,1);
gotoxy(6,33);
cprintf("ATEN��O:");
cor(14,1);
gotoxy(8,35);
cprintf("Apenas a fase em que voc� est� ser� salva e n�o o pregresso dentro dela");
gotoxy(8,37);
cprintf("Escreva o nome SEM espa�os");
for(;;){
cor(15,1);
for(i=1;i<=10;i++){
	gotoxy(10,10+i);
	if (registro[i].fase==0){
		cor(15,1);
		cprintf("Vazio                                               ");
			}
			else{
	cor(14,1);
	cprintf("%s | Fase: %d | Reset: %d",registro[i].nome,registro[i].fase,registro[i].reset);
	switch (registro[i].modo){
			case 1: cprintf(" | Modo livre"); break;
			case 2: cprintf(" | Modo Mov. F�cil"); break;
			case 3: cprintf(" | Modo Mov. M�dio"); break;
			case 4: cprintf(" | Modo Mov. Dif�cil"); break;
			}
	}
	}
cor(14,1);
gotoxy(10,21);
cprintf("CANCELAR");
gotoxy(10,22);
cprintf("APAGAR DADOS");

cor(1,15);
gotoxy(10,10+pos);
if (pos==12){
	cprintf("APAGAR DADOS");
	ajuda("Este comando ira apagar TODOS os jogos salvos",4);
	}else
if (pos==11){
			cprintf("CANCELAR");
			ajuda("Volta",0);
			  }else
if (registro[pos].fase==0){
	cprintf("Vazio");
	ajuda("Pressione enter para salvar aqui",0);
				}else{
					cprintf("%s | Fase: %d | Reset: %d",registro[pos].nome,registro[pos].fase,registro[pos].reset);
						switch (registro[pos].modo){
							case 1: cprintf(" | Modo livre"); break;
							case 2: cprintf(" | Modo Mov. F�cil"); break;
							case 3: cprintf(" | Modo Mov. M�dio"); break;
							case 4: cprintf(" | Modo Mov. Dif�cil"); break;
									}
					  ajuda("Este slot j� est� ocupado, mas voc� pode sobrescreve-lo",4);
					  }
gotoxy(80,25);
ctrl=getch();
switch(ctrl){
	case 'H': pos--; break;
	case 'P': pos++; break;
	case 27: menu(); return 0;
	case 13: switch(pos){
				case 11: volta(); return 0;
				case 12: if (continuar("apagar TODOS os jogos salvos")){
											for(i=1;i<=10;i++)
													registro[i].fase=0;
											salva();
											}
											janela (25,19,55,26,"apagar");

							break;

				default: if (registro[pos].fase!=0)
										if (!continuar("sobrescrever este jogo")){
												janela (25,19,55,26,"apagar");
												break;
												}
							janela (25,19,55,26,"apagar");
							gotoxy(10,10+pos);
							cor(0,1);
							cprintf("                                   ");
							cor(14,1);
							gotoxy(10,10+pos);
							cprintf("Nome: ");
							scanf("%s",registro[pos].nome);
							registro[pos].fase=fase;
							registro[pos].reset=num_reset;
							registro[pos].modo=modo_jogo;
							salva();
							janela(30,20,50,24,"Jogo Salvo");
							cor(1,7);
							gotoxy(32,22);
							cprintf("Pressione ENTER");
							enter();
							volta();
							return 0;
							}
	}
if (pos==13) pos=1;
if (pos==0) pos=12;
}
}

volta(){
monta_borda();
desenha_matriz(1);
estatisticas();
ajuda_ctrl();
jogando();
return 0;
}

ajuda_ctrl(){
gotoxy(4,47);
cor(4,7);
cprintf("%c%c%c%c",24,25,26,27);
cor(0,7);
cprintf("->Movimenta��o ");
cor(4,7);
cprintf("esc/p");
cor(0,7);
cprintf("->Pausa o jogo e acessa o menu");
cor(4,7);
cprintf(" r");
cor(0,7);
cprintf("->Reenicia a fase");
gotoxy(5,48);
cor(4,7);
cprintf("v");
cor(0,7);
cprintf("->Muda a velocidade ");
cor(4,7);
cprintf("m");
cor(0,7);
cprintf("->Liga ou desliga o som ");
cor(4,7);
cprintf("espa�o");
cor(0,7);
cprintf("->Aponta o Face(%c)",1);
return 0;
}

salva(){
FILE *fp;
int i;

if ((fp=fopen("X2.DAT","w"))==NULL) {
	puts("Falhou Abertura! ");
	return 0;
		}
for (i=0;i<=9;i++)
		if (fwrite(&registro[i],sizeof(struct slot), 1,fp) != 1)
			puts("Falha na Gravacao! ");
	fclose(fp);
return 0;
}

carrega(){
FILE *fp;
int i;

if ((fp=fopen("X2.DAT","rb")) == NULL){
	puts("Falha na Abertura do Arquivo!");
	return 0;
	}
for (i=0;i<=9;i++)
	if (fread(&registro[i], sizeof(struct slot), 1, fp) != 1) {
		if (feof(fp)) {
			fclose(fp);
				}
	else {
		puts("Erro de Leitura! ");
		fclose(fp);

		}
	  }
return 0;
}

load_fase(){
int i,j;

switch(fase){
case 1:
x=38; y=21;
esq=dir=bai=0;
cim=1;
mov_max=5;

matriz [38] [19]='X';

matriz [38] [20]=
matriz [76] [17]=
matriz [1] [20]='p';
break;

case 2:
x=75; y=1;
cim=dir=esq=0; bai=1;
mov_max=8;
matriz [34] [18]='X';
paredev(33,5,30);
paredev(35,6,30);
matriz [75] [4]=matriz [76] [4]=matriz [76] [31]=matriz [34] [38]='p';
break;

case 3:
x=31; y=5;
cim=bai=dir=0; esq=1;
mov_max=16;
matriz [40] [20]='X';

paredev(30,1,39);
paredev(50,1,39);

matriz [31][ 6]=
matriz [49] [8]=
matriz [31] [14]=
matriz [49] [20]=
matriz [31] [28]=
matriz [49] [35]='p';
matriz [40] [38]=
matriz [41] [1]=
matriz [31] [1]=
matriz [49] [1]='p';
break;

case 4:
x=1; y=5;
cim=bai=dir=0; esq=1;
mov_max=13;
matriz [76] [1]='X';
paredeh(18,1,75);
paredeh(20,1,75);
paredeh(30,1,77);
paredev(75,1,28);
matriz [35] [18]=' ';
matriz [34] [1]=
matriz [37] [1]=
matriz [37] [17]=
matriz [35] [31]=
matriz [41] [31]='p';
matriz [10] [35]=
matriz [9] [38]=
matriz [40] [37]='p';
matriz [70] [19]='E';
matriz [1] [35]='S';
matriz [40] [35]='E';
matriz [10] [25]='S';
break;

case 5:
x=1; y=4;
bai=cim=dir=0; esq=1;
mov_max=8;

paredev(2,3,34);
paredev(39,3,34);
paredev(41,3,34);
paredev(75,3,34);
for (i=3;i<=37;i=i+4){
			paredeh(i,2,39);
			paredeh(i,41,75);
			}
matriz [1] [3]=
matriz [76] [35]=

matriz [39] [36]=
matriz [41] [1]=
matriz [76] [1]='p';
matriz [76] [2]='E';
for(i=9;i<37;i=i+8){
			matriz [3] [i]='S';
			matriz [74] [i]='E';
			matriz [39] [i]=matriz [41] [i]=' ';
			}
matriz [74] [33]='X';
break;

case 6:
x=40; y=1;
dir=bai=esq=0; cim=1;
mov_max=11;
matriz [20] [4]='X';
paredeh(10,1,77);
matriz [40] [10]=' ';
matriz [30] [9]=25;
matriz [41] [9]=
matriz [40] [20]=
matriz [50] [19]=
matriz [49] [31]=
matriz [29] [30]='p';
matriz [60] [12]='E';
matriz [20] [5]='S';
matriz [72] [5]=
matriz [71] [3]='p';
break;

case 7:
x=20; y=6;
cim=bai=esq=0; dir=1;
mov_max=17;

matriz [19] [4]=
matriz [19] [5]=
matriz [20] [3]=
matriz [21] [6]='p';
matriz [69] [4]=
matriz [68] [3]='p';
matriz [68] [4]=24;
matriz [69] [3]=25;
matriz [70] [4]='E';
matriz [10] [30]='S';
paredeh(18,1,77);
paredeh(20,1,77);
paredev(30,20,39);
matriz [30] [25]=' ';
matriz [29] [26]=
matriz [29] [24]='p';
matriz [29] [23]=25;
matriz [29] [27]=24;
matriz [20] [38]=
matriz [1] [26]='p';
matriz [50] [25]=
matriz [49] [30]='p';
matriz [32] [29]='E';
matriz [76] [19]='S';
matriz [1] [19]='X';
break;

case 8:
x=40; y=24;
cim=esq=dir=0; bai=1;
mov_max=11;
px=58; py=26;
paredeh(25,20,60);
paredeh(27,20,60);
matriz [20] [26]=matriz [58] [26]=matriz [60] [26]='p';
matriz [59] [26]='X';
matriz [59] [24]='E';
matriz [21] [26]='S';
matriz [30] [24]=25;
matriz [40] [1]=
matriz [10] [2]=
matriz [70] [2]=
matriz [11] [30]=
matriz [69] [30]=
matriz [14] [29]=
matriz [15] [30]=
matriz [15] [23]=
matriz [14] [24]=
matriz [1] [21]=
matriz [76] [20]=
matriz [42] [21]='p';
matriz [15] [24]=21;
break;

case 9:
x=33; y=19;
cim=esq=dir=0; bai=1;
mov_max=22;
px=37; py=21;

paredeh(20,35,37);
paredeh(22,35,37);
matriz [36] [21]='X';
matriz [35] [21]=
matriz [37] [21]='p';
matriz [36] [19]=25;
matriz [36] [23]=24;
matriz [34] [21]=26;
matriz [38] [21]=27;
paredev(33,18,24);
paredev(39,18,24);
paredeh(18,33,39);
paredeh(24,33,39);
paredev(31,16,26);
paredev(41,16,26);
paredeh(16,31,41);
paredeh(26,31,41);
matriz [42] [22]=matriz [40] [22]='p';
matriz [42] [21]=21;
paredev(29,14,28);
paredev(43,14,28);
paredeh(14,29,43);
paredeh(28,29,43);
matriz [41] [23]=matriz [39] [21]=matriz [33] [19]=' ';
break;

case 10:
x=37; y=21;
cim=bai=dir=0; esq=1;
px=33; py=21;
mov_max=37;
paredev(35,1,18); paredev(35,24,39);
paredev(37,1,18); paredev(37,24,39);
paredeh(20,1,33); paredeh(22,1,33);
paredeh(20,39,76); paredeh(22,39,76);
matriz [1] [21]='X';
matriz [33] [21]=
matriz [36] [21]=
matriz [36] [19]='p';
matriz [36] [18]=25;
matriz [34] [19]=
matriz [35] [19]=
matriz [38] [19]=
matriz [38] [20]=
matriz [34] [23]=
matriz [34] [22]=
matriz [38] [23]=
matriz [37] [23]='p';
matriz [36] [36]=27;
matriz [74] [21]=
matriz [75] [21]='E';
matriz [1] [10]='S';
matriz [10] [10]='p';
matriz [9] [19]=25;
matriz [9] [2]='E';
matriz [9] [30]='S';
matriz [9] [25]='p';
matriz [8] [35]='E';
matriz [36] [1]='S';
matriz [50] [30]='S';
matriz [76] [30]=
matriz [75] [31]='p';
matriz [75] [28]='E';
matriz [76] [31]=24;
matriz [76] [32]=21;
matriz [55] [10]='S';
matriz [45] [10]=
matriz [60] [10]=
matriz [55] [2]=
matriz [59] [3]='p';
matriz [59] [4]=24;
matriz [45] [3]='E';
matriz [76] [21]='S';
break;

case 11:
x=1; y=21;
cim=bai=dir=0; esq=1;
px=75; py=1;
mov_max=54;

paredeh(20,1,77); paredeh(22,1,77);
paredev(36,1,39);
matriz [37] [21]='X';
matriz [35] [21]='E';
matriz [35] [10]='S';
for (i=10;i<=28;i=i+4){
	for(j=1;j<=20;j=j+2){
			matriz [i] [j+1]=
			matriz [i+2] [j]='p';
		}}
matriz [16] [11]=
matriz [12] [9]=' ';
matriz [25] [11]=
matriz [25] [1]=
matriz [21] [19]=
matriz [19] [10]=
matriz [15] [8]=
matriz [10] [9]=
matriz [11] [14]=
matriz [11] [4]=
matriz [1] [4]=
matriz [1] [6]=
matriz [1] [13]=
matriz [1] [11]=
matriz [2] [8]='p';
matriz [9] [9]='E';
matriz [1] [24]='S';

for (i=3;i<=20;i=i+4){
	paredev(i,24,39);
	paredev(i+2,22,37); }
matriz [2] [38]=26;
matriz [2] [37]='p';
matriz [2] [36]=25;
matriz [5] [37]='E';
matriz [21] [38]='S';
matriz [22] [30]='E';
matriz [35] [29]='p';

matriz [37] [29]='S';
paredeh(28,37,60); paredeh(30,37,60);
paredev(62,24,38); paredev(60,22,37);
paredeh(24,62,75); paredev(75,24,39);
matriz [76] [38]=21;
matriz [60] [29]=' ';
matriz [45] [38]=
matriz [43] [38]=
matriz [46] [32]=
matriz [59] [37]='p';
matriz [46] [33]=24;
matriz [47] [31]=27;
matriz [44] [38]='E';

paredev(75,1,18);
paredeh(18,38,75);
for (i=37;i<=75;i=i+4){
	for(j=5;j<=15;j=j+2){
			matriz [i] [j+1]=
			matriz [i+2] [j]='p';
		}}

matriz [76] [1]='S';
matriz [40] [19]=25;
matriz [37] [19]='E';
matriz [76] [21]='S';
break;

case 12:
x=30; y=31;
esq=bai=dir=0; cim=1;
mov_max=16;

matriz [59] [20]='X';
paredeh(30,2,75);
matriz [1] [30]=16;
matriz [76] [30]=17;
paredev(60,1,25);
paredeh(25,60,76);
matriz [60] [22]=' ';
matriz [1] [20]=
matriz [10] [21]=
matriz [30] [19]=
matriz [10] [11]=
matriz [59] [11]=
matriz [58] [10]=
matriz [58] [20]=
matriz [58] [22]=
matriz [59] [19]=
matriz [76] [15]=
matriz [76] [17]=
matriz [68] [2]=
matriz [69] [23]='p';
paredeh(16,59,76);
matriz [58] [16]=16;
matriz [76] [16]=17;
matriz [1] [10]=16;
matriz [40] [10]=17;
matriz [11] [11]='E';
matriz [73] [2]='S';
break;

case 13:
x=75; y=38;
esq=cim=dir=0; bai=1;
px=70; py=3;
mov_max=28;

matriz [60] [30]=16;
matriz [75] [30]=17;

matriz [70] [31]=24;
matriz [69] [38]=
matriz [75] [28]=
matriz [76] [28]='p';
paredeh(2,2,75);
paredeh(4,1,76);
matriz [71] [4]=' ';
matriz [1] [1]=21;
paredeh(6,2,30);
matriz [28] [3]=
matriz [30] [5]=
matriz [27] [5]=
matriz [27] [7]=
matriz [28] [5]='p';
matriz [29] [4]=
matriz [27] [6]=
matriz [27] [4]=' ';
matriz [27] [5]=26;
matriz [29] [4]=25;
matriz [1] [30]=
matriz [16] [26]=
matriz [23] [14]=
matriz [21] [30]=
matriz [70] [3]=
matriz [70] [5]=
matriz [70] [6]='p';
paredeh(6,30,68);
matriz [31] [5]='X';
break;

case 14:
x=38; y=20;
bai=cim=dir=0; esq=1;
mov_max=11;

for(i=1;i<=76;i++)
		matriz [i] [1]=matriz [i] [38]='a';
for(i=2;i<=38;i++)
		matriz [1] [i]=matriz [76] [i]='a';

matriz [36] [20]='X';
paredeh(21,33,37);
matriz [37] [20]='p';

matriz [75] [20]=
matriz [74] [3]=
matriz [74] [36]='p';
matriz [3] [4]=
matriz [4] [35]='p';
matriz [35] [34]=
matriz [30] [22]=
matriz [70] [22]=
matriz [31] [18]=
matriz [69] [16]=
matriz [69] [37]=
matriz [10] [36]=
matriz [11] [19]='p';
break;

case 15:
x=1; y=4;
cim=bai=dir=0; esq=1;
px=35; py=11;
mov_max=19;

matriz [35] [20]='X';
for(i=25;i<=45;i++)
		matriz [i] [10]=matriz [i] [25]=
		matriz [i] [11]=matriz [i] [24]='a';
for(i=1;i<=76;i++)
	matriz [i] [38]='a';
for(i=25;i<=38;i++)
	matriz [1] [i]=matriz [76] [i]='a';

matriz [35] [10]=
matriz [43] [10]=
matriz [43] [11]=' ';
matriz [35] [11]='p';
paredeh(12,28,42);
matriz [27] [12]=16;
matriz [43] [12]=17;
mar(1,10,25,28);
mar(45,10,76,25);
mar(25,25,45,38);
matriz [10] [35]=21;
matriz [1] [8]=
matriz [54] [1]=
matriz [64] [1]=
matriz [65] [31]=
matriz [73] [30]=
matriz [72] [33]='p';
for(i=10;i<=25;i++)
	matriz [53] [i]=matriz [65] [i]=' ';
for(i=24;i<=30;i++)
	matriz [43] [i]=' ';
matriz [44] [30]=matriz [45] [30]=' ';
for(i=25;i<=45;i++)
	matriz [i] [32]=' ';
matriz [42] [31]='p';
matriz [42] [32]=24;
matriz [2] [32]=
matriz [3] [36]=
matriz [15] [35]=
matriz [14] [31]='p';
matriz [75] [32]=
matriz [74] [26]=
matriz [64] [27]=
matriz [43] [2]=
matriz [34] [3]='p';
matriz [55] [29]=
matriz [65] [35]=
matriz [36] [4]='p';
break;

case 16:
x=40; y=18;
cim=esq=dir=0; bai=1;
px=50; py=20;
mov_max=14;
for(i=1;i<=76;i++)
		matriz [i] [1]=matriz [i] [38]='E';
for(i=2;i<=38;i++)
		matriz [1] [i]=matriz [76] [i]='E';

matriz [69] [20]='X';
matriz [11] [20]='S';
paredeh(19,10,70);
paredeh(21,10,70);
matriz [10] [20]=
matriz [50] [20]=
matriz [70] [20]=
matriz [3] [18]='p';
matriz [7] [20]=16;
matriz [72] [20]=17;
matriz [35] [18]=matriz [45] [18]=25;
matriz [45] [21]=24;
matriz [73] [18]=
matriz [72] [23]=
matriz [72] [5]=
matriz [8] [6]=
matriz [9] [23]=
matriz [46] [22]=
matriz [45] [30]=
matriz [2] [29]=
matriz [5] [19]='p';
matriz [7] [23]=21;
matriz [4] [24]='p';
break;

case 17:
x=40; y=38;
cim=esq=dir=0; bai=1;
px=50; py=20;
mov_max=12;

mar(30,10,50,15);
mar(30,25,50,30);
mar(30,15,35,25);
mar(45,15,50,25);

matriz [37] [23]='X';
matriz [28] [16]=16;
matriz [52] [16]=17;
matriz [40] [20]='S';
matriz [14] [12]='E';

matriz [36] [17]=
matriz [27] [38]=
matriz [28] [11]=
matriz [40] [31]=
matriz [4] [32]=
matriz [5] [11]=
matriz [15] [38]=
matriz [53] [8]=
matriz [1] [9]=
matriz [52] [33]='p';

break;

case 18:
x=41; y=20;
cim=esq=dir=0; bai=1;
mov_max=19;

matriz [31] [20]='X';

for (i=1;i<=78;i=i+2)
	matriz [i] [1]=
	matriz [i] [38]='p';
for (i=20;i<=60;i=i+2)
	matriz [i] [20]=
	matriz [i-1] [21]='p';

matriz [5] [2]=
matriz [6] [37]=
matriz [55] [3]=
matriz [11] [19]=
matriz [12] [30]=
matriz [71] [29]=
matriz [70] [10]=
matriz [28] [11]=
matriz [29] [4]=
matriz [1] [15]=
matriz [32] [14]='p';
matriz [40] [30]=
matriz [38] [10]=
matriz [1] [3]='p';
break;

case 19:
x=40; y=9;
cim=bai=dir=0; esq=1;
px=6; py=4;
mov_max=16;

mar(30,10,50,30);
matriz [40] [20]='X';
matriz [40] [21]=' ';
matriz [40] [22]='S';
paredeh(9,29,51);
paredeh(31,29,51);
paredev(29,10,30);
paredev(51,10,30);
matriz [40] [9]=' ';
matriz [27] [21]=16;
matriz [53] [21]=17;
matriz [25] [31]='p';
matriz [28] [31]=16;
matriz [52] [31]=17;
matriz [40] [7]=
matriz [26] [8]=
matriz [53] [8]='p';
paredeh(37,25,55);
paredeh(2,5,73);
matriz [40] [32]=21;
matriz [39] [36]='p';
matriz [52] [2]=' ';
matriz [73] [3]=
matriz [72] [37]=
matriz [73] [32]=
matriz [73] [36]=
matriz [5] [3]='p';
paredeh(4,5,73);
matriz [27] [4]=
matriz [52] [4]=
matriz [72] [4]=' ';
matriz [6] [33]='E';
matriz [7] [32]=
matriz [2] [31]=
matriz [3] [37]=
matriz [7] [36]='p';
matriz [8] [32]=27;
break;

case 20:
x=33; y=9;
cim=esq=dir=0; bai=1;
px=51; py=18;
mov_max=28;


paredev(14,10,30);
paredev(15,10,30);
paredeh(10,16,25);
paredeh(11,16,24);
paredeh(18,16,22);
paredeh(19,16,21);

paredev(32,10,30);
paredev(33,10,30);
matriz [32] [7]=
matriz [32] [8]=
matriz [33] [7]=
matriz [33] [8]='p';

paredev(41,10,30);
paredev(42,10,30);
j=10;
for(i=43;i<=59;i++){
		matriz [i] [j]=
		matriz [i] [j+1]=
		matriz [i] [j+2]='p';
		if (i<=50) j++;
			else
			 j--;
		}
paredev(60,10,30);
paredev(61,10,30);
matriz [51] [19]='X';

matriz [28] [9]=
matriz [29] [35]=
matriz [24] [34]=
matriz [31] [20]=
matriz [23] [38]=
matriz [1] [25]='p';
matriz [22] [19]=21;
matriz [22] [38]='E';
matriz [76] [20]='S';
matriz [75] [1]=
matriz [75] [38]=
matriz [35] [2]='p';
matriz [31] [1]=
matriz [1] [2]=
matriz [40] [38]='p';
matriz [43] [1]=
matriz [58] [2]=
matriz [45] [3]=
matriz [56] [5]=
matriz [47] [6]=
matriz [54] [7]=
matriz [50] [8]='p';


break;

default: return 0;
}

return 0;
}