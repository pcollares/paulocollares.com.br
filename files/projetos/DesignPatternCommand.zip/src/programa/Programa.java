package programa;

import telas.ControleRemoto;

/**
 * @author Paulo Collares
 * www.paulocollares.com.br
 */
public class Programa {

    public static void main(String[] args) {
        new ControleRemoto();
    }
    
}
