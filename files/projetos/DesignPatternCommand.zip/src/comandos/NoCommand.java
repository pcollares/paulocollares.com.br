package comandos;

/**
 * @author Paulo Collares
 * www.paulocollares.com.br
 */
public class NoCommand implements Command{

    @Override
    public void execute() {
        
    }

    @Override
    public void undo() {
        
    }
    
}
