
/*Snake Challenge 2*/

#include<conio.h>
#include<stdio.h>
#include<bios.h>
#include<time.h>
#include<dos.h>
#include<bios.h>
#include<string.h>
#include <stdlib.h>

struct registro {
	char nome[10];
	int fase;
	unsigned int pnt;
} matriz2[9];


char matriz [80] [25];
unsigned int pnt;
int x,y,
xx,yy,
xd,yd,hor,ver,
xd2,yd2,hor2,ver2,
cim,bai,esq,dir,
ctrl,
end,
tx[202],ty[202],
tam,vida,fase,
time_pnt,
s,
v,vdelay,
cem_pnt,
cloop;

void main(){
clrscr();
gotoxy(18,15);
printf("Pressione [alt+enter] para jogar em tela cheia");
getch();
clrscr();
sc2();
gotoxy(23,15);
textcolor(15+225);
textbackground(14);
cprintf("Pressione Qualquer Tecla Para Iniciar");
gotoxy(24,22);
textcolor(0);
cprintf("SC2 - Snake Challenge 2 - ver 1.0");
gotoxy(25,23);
cprintf("Desenvolvido por Paulo Collares");
gotoxy(22,24);
cprintf("dez/06-jan/07 - Compilado no Turbo C",184);
gotoxy(1,1);

ctrl=getch();
if (ctrl==27) goto loop2;

s=1;
loop1:
vida=3;
end=fase=0;

sc2();
if (menu()) goto loop2;

pnt=0;
v=3;
tam=1;
cloop=0;
xd=yd=xd2=yd2=0;
ver=hor=ver2=hor2=0;

for(;;){
fase++;
novo();

for(;;){
if (cloop) goto loop1;

gotoxy(8,3);
textcolor(0);
textbackground(2);
cprintf("%c ",178);

textcolor(7);
textbackground(0);
cprintf(" x %d",vida);

textcolor(2);
cprintf("      %c%d%c ",27,tam,26);

textcolor(7);
cprintf("      %c",1);

textcolor(10);
switch(cem_pnt){
	case 1: cprintf("*    "); break;
	case 2: cprintf("**   "); break;
	case 3: cprintf("***  "); break;
	case 4: cprintf("**** "); break;
	case 5: cprintf("*****"); break;
	default:cprintf("     "); break;
	}

textcolor(7);
cprintf("     Vel.|");
switch(v){
	case 1: vdelay=20000;
		textcolor(10);
		cprintf("%c    ",254);
		break;
	case 2: vdelay=5000;
		textcolor(9);
		cprintf("%c%c   ",254,254);
		break;
	case 3: vdelay=0;
		textcolor(6);
		cprintf("%c%c%c  ",254,254,254);
		break;
	case 4: vdelay=-2500;
		textcolor(14);
		cprintf("%c%c%c%c ",254,254,254,254);
		break;
	case 5: vdelay=-5000;
		textcolor(4);
		cprintf("%c%c%c%c%c",254,254,254,254,254);
		break;
		}

printf("|      pontos:");
textcolor(7);
if (pnt<10) cprintf("0000000%d",pnt);
if ((pnt>=10)&&(pnt<100)) cprintf("000000%d",pnt);
if ((pnt>=100)&&(pnt<1000)) cprintf("00000%d",pnt);
if (pnt>=1000) cprintf("0000%u",pnt);
if (s==0){ textcolor(4);

cprintf("    %c",14);} else
cprintf("     ");

gotoxy(1,25);
printf("w,a,s,d->movimentos | q,e->vel. | p->pausa | m-mute | n->novo jogo | esc->sair");

gotoxy(65,1);
printf("-DEUS %c Fiel-",130);

gotoxy(80,25);
printf("");


if ((dir==1)||(esq==1)) delay(10000+vdelay);
if ((cim==1)||(bai==1)) delay(15000+vdelay);
if ((cim==0)&&(bai==0)&&(esq==0)&&(dir==0)) delay(10000+vdelay);


nosound();

if (!(cim==bai==esq==dir)) sound(s*400);

stop();
desenha_matriz();
cauda();

if (vencer()){
	 gotoxy(x,y);
	 textcolor(2);
	 cprintf("%c",219);
	 sound(s*900);
	 delay(9000000);
	 sound(s*800);
	 delay(9000000);
	 sound(s*950);
	 sleep(1);
	 nosound();
	 break;
	 }

gotoxy(x,y);
matriz [x] [y]=219;
textcolor(2);
cprintf("%c",matriz [x] [y]);

if (bioskey(1)) controles();

x=x+dir-esq;
y=y+bai-cim;

if (xd>0){
	matriz [xd] [yd]='d';
	if ((xd==x)&&(yd==y)) morre();
	if ((matriz [xd+1] [yd]!=' ')||(matriz [xd-1] [yd]!=' ')) hor=hor*-1;
	if ((matriz [xd] [yd+1]!=' ')||(matriz [xd] [yd-1]!=' ')) ver=ver*-1;

	gotoxy(xd,yd);
	textcolor(4);
	textbackground(14);
	cprintf("%c",207);

	textcolor(7);
	matriz [xd] [yd]=' ';

	xd=xd+hor;
	yd=yd+ver;
	}

if (xd2>0){
	matriz [xd2] [yd2]='e';
	if ( ( ( (xd2==x)||(xd2+1==x)||(xd2-1==x) ) && (yd2==y)	)||( ( (yd2==y)||(yd2-1==y)||(yd2+1==y) )&&(xd2==x))) {
			sound(s*1000);
			delay(100000);
			vida=vida+2;
			pnt=pnt+800;
			matriz [xd2] [yd2]=' ';
			xd2=0;
			goto loop3;
			}
	if ((matriz [xd2+1] [yd2]!=' ')||(matriz [xd2-1] [yd2]!=' ')) hor2=hor2*-1;
	if ((matriz [xd2] [yd2+1]!=' ')||(matriz [xd2] [yd2-1]!=' ')) ver2=ver2*-1;

	gotoxy(xd2,yd2);
	textcolor(2);
	textbackground(14);
	cprintf("%c",15);

	matriz [xd2] [yd2]=' ';

	xd2=xd2+hor2;
	yd2=yd2+ver2;

	loop3:
	textcolor(7);
	}

if (matriz [x] [y]=='a'){ /*alvo*/
		if (tam<200) tam++;
		sound(s*700);
		delay(10000);
		troca(&xx,&yy);
		if (time_pnt<10) pnt=pnt+10;
		if ((time_pnt>=10)&&(time_pnt<=80)) pnt=pnt+5;
		if ((time_pnt>80)&&(time_pnt<=110)) pnt=pnt+3;
		if ((time_pnt>110)&&(time_pnt<=150)) pnt=pnt+2;
		if (time_pnt>150) pnt++;
		pnt=pnt+(v*3);
		time_pnt=0;

		}

if (matriz [x] [y]==1){ /*moeda especial*/
			cem_pnt++;
			pnt++;
			sound(s*1000);
			delay(1000);
			if (cem_pnt==5){
					 sound(s*700);
					 delay(900000);
					 sound(s*750);
					 pnt=pnt+1200;}
			}

if (matriz [x] [y]=='E') buraco();

if (matriz [x] [y]=='b') bomba();

if(matriz [x] [y]=='1'){ /*moeda de um ponto*/
			sound(s*900);
			pnt++;
			}

if (matriz [x] [y]=='$'){ /*moeda de 10 pontos*/
			sound(s*950);
			delay(100000);
			pnt+=10;
			}

if (matriz [x] [y]==3){ /*vida*/
			sound(s*900);
			delay(1000000);
			sound(s*950);
			pnt++;
			vida++;
			}

if ((matriz [x] [y]==19)&&(v==5)){ /*dinamite*/
			sound(s*300);
			textcolor (4);
			textbackground(14);
			gotoxy(x-1,y-1);
			cprintf("%c%c%c",177,177,177);
			gotoxy(x-1,y);
			cprintf("%c%c%c",177,177,177);
			gotoxy(x-1,y+1);
			cprintf("%c%c%c",177,177,177);

			delay(100000000);

			matriz [x+1] [y]=
			matriz [x-1] [y]=
			matriz [x] [y+1]=
			matriz [x] [y-1]=
			matriz [x+1] [y+1]=
			matriz [x-1] [y-1]=
			matriz [x+1] [y-1]=
			matriz [x-1][ y+1]=' ';
			}
time_pnt++;

matriz [xx] [yy]='a';

if (vida==-1) break;
if (end==1) goto loop2;
}



if (vida==-1){
	nosound();
	clrscr();
	zera_matriz();

	sc2();
	gotoxy(33,10);
	end=1;

	textcolor(3+225);
	textbackground(14);
	cprintf("!GAME OVER!");

	textcolor(0);
	printf("\n\n\t\t\t");
	cprintf("   Sua pontua%c%co foi de: %d ",135,198,pnt);
	printf("\n\t\t\t   ");

	if (fase<100) cprintf("Voc%c completou %d fase(s)",136,fase-1); else
	cprintf("     Com tamanho %d",tam);

	printf("\n\n\t\t\t   ");
	score();
	s=end=1;


	}

if ((end==1)||(ctrl==27)) break;

if (fase>0){
	clrscr();
	zera_matriz();
	sc2();
	xd=xd2=0;

	gotoxy(33,15);
	textcolor(1+225);
	textbackground(14);
	cprintf("Miss%co %d completa!",198,fase);

	gotoxy(28,16);
	textcolor(0);
	cprintf("Voc%c tem %d Pontos e %d vida(s)",136,pnt,vida);

	gotoxy(28,19);
	cprintf("Pressione [enter] para continuar");

	enter();
	clrscr();
	}
}


clrscr();
zera_matriz();
goto loop1;
loop2:
nosound();
}

/*funcoes*/

enter(){
char c;
do {
	c=getch();
	} while(!(c==13));
}

troca(int *x,int *y){
int x2,y2;
do{
	x2=rand()%75+3;
	y2=rand()%19+5;
	} while ((matriz [x2] [y2]=='p')||(matriz [x2] [y2]=='c'));
    *x=x2;
    *y=y2;
    }

fim(){
int i;
clrscr();
zera_matriz();
sc2();

textcolor(2);
textbackground(14);

for (i=0;i<=14;i++){
gotoxy(3,10+i);
cprintf("Parab%cns",130);
gotoxy(69,10+i);
cprintf("Parab%cns",130);}
gotoxy(27,11);
textcolor(0);
cprintf("Voc%c zerou o Snake Challenge 2",136);
gotoxy(21,13);
cprintf("  Sua pontua%c%co final foi de ",135,198);

for (i=0;i<=pnt;i++){
		gotoxy(50,13);
		cprintf("%u",i);
		sound(s*200);
		delay(100);
		nosound();
			}
cprintf(" pontos");
gotoxy(27,20);
score();
}

controles(){
ctrl=getch();

switch(ctrl){
case 'a':if (dir==1) break;
	if ((matriz [x-1] [y]=='c')||(matriz [x-1] [y]=='p')) break;
	dir=cim=bai=0;
	 esq=1;
	 break;
case 'd':if (esq==1) break;
	if ((matriz [x+1] [y]=='x')||(matriz [x+1] [y]=='p')) break;
	esq=cim=bai=0;
	dir=1;
	break;
case 'w':if (bai==1) break;
	if ((matriz [x] [y-1]=='c')||(matriz [x] [y-1]=='p')) break;
	esq=bai=dir=0;
	cim=1;
	break;
case 's':if (cim==1) break;
	if ((matriz [x] [y+1]=='c')||(matriz [x] [y+1]=='p')) break;
	cim=dir=esq=0;
	bai=1;
	break;
case 27:gotoxy(28,9);
	textcolor(224);
	textbackground(15);
	cprintf("      Sair       ");
	if (continuar()) end=1;
	break;
case 'p':
	texto();
	nosound();
	textcolor(14+225);
	gotoxy(36,8);
	cprintf("-JOGO EM PAUSA-");
	gotoxy(1,1);
	textcolor(7);
	textbackground(0);
	getch();
	break;
case 'n':gotoxy(28,9);
	textcolor(224);
	textbackground(15);
	cprintf("    Novo Jogo    ");
	if (continuar()){
		cloop=1;
		clrscr();
		zera_matriz(); }
	break;
case 'e':v++;
	if (v==6) v=5;
	break;
case 'q':v--;
	if (v==0) v=1;
	break;
case 'm':if (s==1) s=0;
	else s=1;
	break;
default: return 0;
	}
}

stop(){
if ((matriz [x] [y]=='p')||(matriz [x] [y]=='c')){
						morre();
						}
}

morre(){
int i;
vida--;

textcolor(2);
textbackground(0);

if (vida>=0){
gotoxy(33,15);
if (vida==1) cprintf(" %d vida restante ",vida); else cprintf("%d vidas restantes",vida);

gotoxy(33,15);
if (vida==0) cprintf("   %cLTIMA VIDA   ",233);

gotoxy(33,16);
cprintf("pressione [enter]");}

textcolor(4);
gotoxy(x,y);
cprintf("%c",178);

gotoxy(1,1);

sound(s*500);
delay(9000000);

for (i=0;i<=tam;i++){
	matriz [tx[i]] [ty[i]]=' ';
	tx[i]=ty[i]=20;
		}
x=y=20;
cim=bai=esq=dir=0;
sleep(1);
nosound();
if (vida>=0) enter();
}

zera_matriz(){
int i,j;

for (i=0;i<=80;i++)
	for (j=0;j<=25;j++)
		matriz [i] [j]=' ';

for (i=0;i<=tam;i++)
		tx[i]=ty[i]=20;
}

monta_borda(){
int i;

for (i=0;i<=80;i++){
	matriz [1+i] [4]=
	matriz [1+i] [24]='p';
		}

for (i=0;i<=20;i++){
	matriz [2] [5+i]=
	matriz [79] [5+i]=
	matriz [1] [5+i]=
	matriz [80] [5+i]='p';
		}
}

desenha_matriz(){
int i, j;

textbackground(0);

for (i=1;i<=tam;i=i+3)
	matriz [tx[i]] [ty[i]]='c';

	for (i=1;i<=80;i++){
		for (j=4;j<=24;j++){
			gotoxy(i,j);
			textcolor(8);
			textbackground(7);

			if (matriz [i] [j]=='p')
					cprintf("%c",178);
						else{
							textcolor(2);
							textbackground(6);
							cprintf("%c",matriz [i] [j]);
						     }

			if (matriz [i] [j]=='c'){
					gotoxy(i,j);
					textcolor(0);
					textbackground(2);
					cprintf("%c",178);
						}

			if (matriz [i] [j]=='a'){
					gotoxy(i,j);
					textcolor(14);
					cprintf("%c",207);
					}

			if (matriz [i] [j]=='1'){
					gotoxy(i,j);
					textcolor(time_pnt%3+9);
					cprintf("%c",169);
					}

			if (matriz [i] [j]==3){
					gotoxy(i,j);
					textcolor(time_pnt%2+4);
					cprintf("%c",3);
					}

			if (matriz [i] [j]=='$'){
					gotoxy(i,j);
					textcolor(time_pnt%2+14);
					cprintf("$");
					}

			if (matriz [i] [j]=='s'){
					gotoxy(i,j);
					textcolor(time_pnt%2+1);
					cprintf("%c",127);
					}

			if (matriz [i] [j]==1){
					gotoxy(i,j);
					textcolor(time_pnt%2+10);
					cprintf("%c",1);
					}

			if (matriz [i] [j]=='b'){
					gotoxy(i,j);
					textcolor(4);
					cprintf("%c",157);
					}

			}
			}
textbackground(0);
}

cauda(){
int i;

tx[0]=x;
ty[0]=y;
matriz [tx[tam]] [ty[tam]]=' ';

for(i=tam;i>=0;i--){
	tx[i]=tx[i-1];
	ty[i]=ty[i-1];
	}
}

novo(){
int i,j;
ctrl=' ';
cem_pnt=0;
zera_matriz();
textbackground(0);

for (i=1;i<=80;i++){
	for (j=1;j<=4;j++){
		gotoxy(i,j);
		cprintf("%c",matriz [i] [j]);
			}
gotoxy(i,25);
cprintf("%c",matriz [i] [25]);
}

monta_borda();
textcolor(7);
textbackground(0);

clrscr();
gotoxy(1,1);
textcolor(2);

if (fase<100)
	cprintf("S.C.2 - Miss%co 00%d - by paulo collares",198,fase);
		else
			cprintf("S.C.2 - Fase Livre - by paulo collares");
switch(fase){
case 1:	fase_1(); texto(); enter(); break;
case 2: fase_2(); texto(); enter(); break;
case 3: fase_3(); texto(); enter(); break;
case 4: fase_4(); texto(); enter(); break;
case 5: fase_5(); texto(); enter(); break;
case 6: fase_6(); texto(); enter(); break;
case 7: fase_7(); texto(); enter(); break;
case 8: fase_8(); texto(); enter(); break;
case 9: fase_9(); texto(); enter(); break;
case 10: fase_10(); texto(); enter(); break;
case 100: fase_livre(); break;

default:fase=0;
	fim();
	end=1;
	}
troca(&xx,&yy);
}

texto(){
int i,j;
textcolor(2);
textbackground(0);

for (i=0;i<=79;i++){
	for (j=0;j<=10;j++){
		gotoxy(1+i,9+j);
		cprintf(" ");
		}
		}
gotoxy(40,10);
if (fase<100)
	cprintf("Miss%co %d",198,fase);
		else
		printf("Fase Livre");
gotoxy(28,11);

switch(fase){
case 1: printf("\n\t\t\t   Objetivo: Atinja tamanho 10");
	printf("\n\n\t\t\t   Novos Objetos: \n\t\t\t   %c-> Alvo \n\t\t\t   %c-> +1 ponto \n\t\t\t   %c-> +10 pontos \n\t\t\t   %c-> +1 vida",207,169,36,3);
	break;
case 2: printf("\n\t\t\t   Objetivo: Atinja tamanho 20\n\t\t\t   para abrir a passagem secreta\n\t\t\t   e pegar o '%c'.",127);
	printf("\n\n\t\t\t   Novos Objetos: \n\t\t\t   %c-> saida \n\t\t\t   %c-> moeda especial,\n\t\t\t     junte as 5 para ganhar 800 pontos",127,1);
	break;
case 3: printf("\n\t\t\t   Objetivo: Pegue o '%c'",127);
	printf("\n\n\t\t\t   Novos Objetos: \n\t\t\t   'E'-> entrada do buraco negro \n\t\t\t   'S'-> saida do buraco negro");
	break;
case 4: printf("\n\t\t\t   Objetivo: Pegue o '%c'",127);
	printf("\n\n\t\t\t   Novo Objeto: \n\t\t\t   %c-> dinamite\n\t\t\t        (atinja-o em VELOCIDADE M%cXIMA\n\t\t\t   para quebrar as paredes ao redor)",19,181);
	break;
case 5: printf("\n\t\t\t   Objetivo: Pegue o '%c'",127);
	printf("\n\n\t\t\t   Novos Objetos: \n\t\t\t   %c-> super bonus (+2 vidas e +1200 pontos)\n\t\t\t   %c-> alvo mal criado (ele te mata)",15,207);
	break;
case 6: printf("\n\t\t\t   Objetivo: Atinja tamanho 45");
	break;
case 7: printf("\n\t\t\t   Objetivo: Pegue o '%c'",127);
	printf("\n\n\t\t\t   Lembre-se de atingir o\n\t\t\t    '%c' com velocidade maxima",19);
	break;
case 8: printf("\n\t\t\t   Objetivo: Pegue o '%c'",127);
	printf("\n\n\t\t\t   Novo Objeto: \n\t\t\t   %c-> bomba\n\t\t\t       (destr%ci as paredes em volta)",157,162);
	break;
case 9: printf("\n\t\t\t   Objetivo: Atinja tamanho 150");
	break;
case 10: printf("\n\t\t\t\t   DESAFIO FINAL\n\n\t\t\t   Objetivos: atinja tamanho 200 para\n\t\t\t   abrir a passagem secreta\n\t\t\t   e pegar o '%c'",127);
	break;
case 100: printf("\n\t\t\t   Objetivo: Jogo livre, quebre seus records");
	 break;
default:break;
}
}

int vencer(){
switch(fase){
case 1:if (tam==10) return 1;
	break;
case 2: if (matriz [39] [13]=='p'){
	gotoxy(39,13);
	textbackground(14);
	cprintf("%c",178); }
	if (tam==20) matriz [39] [13]=' ';
	if (matriz [x] [y]=='s') return 1;
	break;
case 3:if (matriz [x] [y]=='s') return 1;
	break;
case 4: matriz [50] [20]=19;
	if (matriz [x] [y]=='s') return 1;
	break;
case 5: matriz [70] [6]='s';
	if (matriz [x] [y]=='s') return 1;
	break;
case 6: if (tam==45) return 1;
	break;
case 7: matriz [48] [20]=matriz [65] [9]=matriz [36] [6]=19;
	matriz [78] [22]='S'; matriz [59] [5]='E';
	if (matriz [x] [y]=='s') return 1;
	break;
case 8: matriz [3] [21]='E'; matriz [78] [5]='S';
	if (matriz [x] [y]=='s') return 1;
	break;
case 9: if (tam==150) return 1;
	break;
case 10:matriz [74] [4]=matriz [75] [4]=matriz [76] [4]='p';
	matriz [75] [5]=19;
	matriz [3] [5]='S';
	matriz [78] [8]='E';
	matriz [76] [8]=19;
	if (matriz [77] [5]=='p'){
	gotoxy(77,5);
	textbackground(14);
	cprintf("%c",178);}
	if (tam==200) matriz [77] [5]=' ';
	if (matriz [x] [y]=='s') return 1;
	break;
default: return 0;
	}
return 0;
}

buraco(){
int i,j;

for (i=0;i<=79;i++){
	for (j=0;j<=25;j++){
	sound(s*300);
	delay(50);
	nosound();
		if (matriz [i] [j]=='S'){
		matriz [x] [y]=' ';
		x=i;
		y=j;
		return 0;
					}
		}
		}
}

bomba(){
int bx,by;

bx=x;
by=y;
pnt=pnt+40;

do{
if (matriz [bx+1] [by]=='p'){
				bx++;
				goto loop1;
				}
if (matriz [bx-1] [by]=='p'){
				bx--;
				goto loop1;
				}
if (matriz [bx] [by+1]=='p'){
				by++;
				goto loop1;
				}
if (matriz [bx] [by-1]=='p'){
				by--;
				goto loop1;
				}
if (matriz [bx] [by]!='p') break;

loop1:
gotoxy(bx,by);
textcolor(4);
textbackground(14);
cprintf("%c",178);
gotoxy(bx+1,by);
cprintf("%c",176);
gotoxy (bx-1,by);
cprintf("%c",176);
gotoxy(bx,by+1);
cprintf("%c",176);
gotoxy(bx,by-1);
cprintf("%c",176);
gotoxy(1,1);

sound(s*300);
delay(5000);
nosound();
matriz [bx] [by]=' ';
desenha_matriz();
delay(1000);
nosound();
	}while (matriz [bx] [by]!='p');

}

int continuar(){
int m;
m=1;
nosound();
textcolor(2);
textbackground(0);

do {
gotoxy(28,10);
cprintf("Voc%c Tem Certeza?",136);
gotoxy(28,11);
cprintf("    Sim   ");
gotoxy(38,11);
cprintf("N%co    ",198);

if (m==1){
	gotoxy(31,11);
	cprintf("%c",16);
	gotoxy(37,11);
	cprintf(" ");
	}

if (m==2){
	gotoxy(37,11);
	cprintf("%c",16);
	gotoxy(31,11);
	cprintf(" ");
	}

gotoxy(1,2);
cprintf(" ");

ctrl=getch();

switch(ctrl) {
case 'a':
case 75: m--;
	break;
case 'd':
case 77: m++;
	break;
case 13: switch(m){
	case 1: return 1;
	case 2: return 0;
		}
default: break;
}

if (m==3) m=2;
if (m==0) m=1;
	}while(!(ctrl==13));

}

sc2(){
int i,j;
zera_matriz();

/*S*/
for(i=0;i<=2;i++)
	matriz [25+i] [4]=matriz [24] [4+i]=matriz [25+i] [6]=matriz [27] [6+i] =matriz [24+i] [8]='p';

/*C*/
for (i=0;i<=2;i++)
	matriz [34+i] [4]=matriz [34+i] [8]='p';
for (i=0;i<=4;i++)
	matriz [33] [4+i]='p';

/*2*/
for(i=0;i<=2;i++)
	matriz [46+i] [4]=matriz [49] [4+i]=matriz [46+i] [6]=matriz [46] [6+i] =matriz [47+i] [8]='p';
for (i=3;i<=76;i++)
	matriz [1+i] [10]='p';

textcolor(0);
textbackground(2);

for (i=0;i<=80;i++){
	for (j=0;j<=25;j++){
		textcolor(2);
		textbackground(14);
		gotoxy(i,j);
		if (matriz [i] [j]=='p'){
			 textcolor(0);
			 textbackground(2);
			 cprintf("%c",178);
			 } else
		cprintf("%c",matriz [i] [j]);
			}
			}
textcolor(0);
textbackground(2);
gotoxy(28,6);
cprintf("nake");
gotoxy(37,6);
cprintf("hallenge");
gotoxy(57,7);
cprintf("by Paulo Collares");
}

int menu(){
int m;
m=1;
textcolor(0);
textbackground(14);

do {
gotoxy(25,21);
cprintf("Pressione [enter] para confirmar");
gotoxy(33,15);
cprintf("Jogar Miss%ces do S.C.2",228);
gotoxy(33,16);
cprintf("Jogar Fase Livre");
gotoxy(33,17);
cprintf("Ajuda");
gotoxy(33,18);
cprintf("Ver Placar");
gotoxy(33,19);
cprintf("Sair do S.C.2");

gotoxy(32,14+m);
textcolor(14);
cprintf("%c",207);
textcolor(0);
gotoxy(1,1);
cprintf(" ");

ctrl=getch();
sound(s*900);
delay(1000);
nosound();

switch(ctrl) {
case '^':gotoxy(1,1);
	 cprintf("fase?: ");
	 scanf("%d",&fase);
	 if ((fase<1)||(fase>10)){
				 fase=1;
				 gotoxy(1,1);
				 cprintf("             ");
				 break;
				 }
	 fase--;
	 return 0;
case 'w':
case 72:gotoxy(32,14+m);
	cprintf("  ");
	m--;
	break;
case 's':
case 80:gotoxy(32,14+m);
	cprintf("  ");
	m++;
	break;
case 'm':if (s==1) s=0;
	else s=1;
	break;
case 13: switch(m){
	case 1:	fase=0;
		return 0;
	case 2:	fase=99;
		vida=0;
		return 0;
	case 4: carrega();
		escreve();
		getch();
		sc2();
		menu();
		break;
	case 3:	ajuda();
		sc2();
		menu();
		break;
	case 27:
	case 5: return 1;
	}
default: break;
}

if (m==6) m=1;
if (m==0) m=5;

	}while(!((ctrl==13)||(ctrl==27)));
}

ajuda(){
clrscr();
printf(" ");
textbackground(2);

cprintf("  Ajuda do Snake Challenge 2                       by paulo collares          ");

printf("\n\nControles:\n w,a,s,d - movimenta%c%co\n q - diminui a velocidade\n e - aumenta a velocidade\n",135,198);
printf(" p - pausa o jogo e rever os objetivos\n n - novo jogo\n m - ativa e desativa o som\n esc - sai do jogo");

printf("\n\nComo Jogar:\n Controle a serpente atrav%cs das fases, pegue o maximo de pontos possivel.\n Quanto mais rapido voc%c andar e mais rapido pegar os alvos mais pontos ganhar%c",198,136,160);

printf("\n\nObjetos:\n %c-> Alvo \t%c-> +1 ponto \t%c-> +10 pontos \t%c-> +1 vida \t",207,169,36,3);
printf(" %c-> saida \n %c-> moeda especial, junte as 5 para ganhar 800 pontos\n",127,1);
printf(" 'E'-> entrada do buraco negro \t'S'-> saida do buraco negro \n %c-> dinamite (atinja-o em VELOCIDADE M%cXIMA para quebrar as paredes ao redor)\n",19,181);
printf(" %c-> super bonus (+2 vidas e +1200 pontos) \n %c(vermelho)-> alvo mal criado (ele te mata) \n",15,207);
printf(" %c-> bomba (destr%ci as paredes em volta)",157,162);

printf("\n\nBoa Sorte ;)\t\t\tpressione qualquer tecla para continuar");

getch();
clrscr();
}

/*funcoes das fases*/

fase_1(){
int i;

x=y=20;
cim=bai=esq=dir=0;
tam=1;

for(i=0;i<=25;i++)
	matriz [6+i] [15]=matriz [30+i] [10]='p';
for(i=0;i<=10;i++)
	matriz [55] [5+i]=matriz [62] [13+i]='p';

matriz [25] [8]=matriz [34] [12]=matriz [66] [15]='p';

for (i=0;i<=25;i++)
	matriz [6+i] [14]='1';

matriz [25] [7]='1';
matriz [55] [12]='$';
matriz [66] [14]=3;
}

fase_2(){
int i,j;
x=y=20;
cim=esq=bai=dir=0;

matriz [40] [13]='s';
for (i=0;i<=2;i++)
	matriz [39+i] [12]=matriz [39+i] [14]='p';
matriz [39] [13]=matriz [41] [13]='p';
matriz [30] [13]='p';

for (j=0;j<=1;j++){
for (i=0;i<=10;i++){
	 matriz [43+i+i+j] [10+i]='p';
	 matriz [46+i+i] [10+i]='1';
		}
		 }
matriz [78] [23]=3;

for (i=0;i<=30;i++)
	matriz [20+i] [7]=matriz [47+i] [22]='p';

matriz [60] [23]=matriz [49] [12]=matriz [46] [12]=matriz [40] [6]=matriz [77] [13]=1;
}

fase_3(){
int i,j;
x=y=20;
cim=bai=esq=dir=0;
xx=45;yy=12;

for (i=0;i<=7;i++)
	matriz [60] [9+i]='p';

matriz [5] [17]='E'; matriz [5] [15]='S';
matriz [59] [10]='E'; matriz [61] [10]='S';

matriz [78] [5]='s';
for (i=0;i<=10;i++)
	for (j=0;j<=5;j++)
		matriz [40+i] [10+j]='1';

for (i=0;i<=58;i++)
	matriz [33+i] [6]=matriz [2+i] [16]=matriz [2+i] [9]='p';
matriz [33] [5]=' ';
matriz [44] [23]='$';
matriz [44] [8]= matriz [55] [5]=matriz [5] [7] =matriz [32] [14]=matriz [10] [22]=1;
}

fase_4(){
int i;
x=y=20;
cim=bai=esq=dir=0;

matriz [77] [22]='s';
for (i=0;i<=30;i++)
	matriz [42+i] [19] = matriz [42+i] [21]='p';
for (i=0;i<=20;i++)
	matriz [51] [5+i]=matriz [12+i] [10]=matriz [12+i] [8]='p';
matriz [50] [20]=19;

for (i=0;i<=20;i++)
	matriz [25+i] [18]='1';

matriz [72] [13] = matriz [25] [9] = matriz [61] [20] = matriz [78] [13] = matriz [30] [12]=1;
matriz [30] [9]='$';
matriz [60] [23]=3;
matriz [71] [13]='p';
}

fase_5(){
int i;
x=y=20;
cim=bai=esq=dir=0;

xd=40; yd=6;
hor=-1; ver=1;

xd2=50; yd2=10;
hor2=1; ver2=-1;

matriz [70] [6]='s';

for (i=0;i<=50;i++)
	matriz [30+i] [8]=matriz [15+i] [17]='p';
for (i=0;i<=2;i++)
	matriz [30] [5+i]=matriz [60] [5+i]='p';

matriz [60] [6]=matriz [30] [6]=' ';
for (i=0;i<=7;i++)
	matriz [40] [9+i]=matriz [60] [9+i]='1';

matriz [31] [5]=matriz [59] [5]='$';

matriz [61] [7]=matriz [78] [7]=matriz [44] [13]=matriz [3] [6]=matriz [76] [15]=1;
}

fase_6(){
int i;
x=y=20;
cim=bai=esq=dir=0;
tam=30;

xd=21; yd=8;
ver=hor=1;

xd2=60; yd2=22;
ver2=hor2=1;

for (i=0;i<=76;i++)
	matriz [3+i] [14]='p';
for (i=0;i<=19;i++)
	matriz [38] [5+i]=matriz [39] [5+i]='p';
for (i=0;i<=1;i++)
	matriz [20+i] [14]=matriz [55+i] [14]=matriz [38+i] [9]=matriz [38+i] [20]=' ';
for (i=0;i<=34;i++)
	matriz [3+i] [13]='1';
for (i=0;i<=8;i++)
	matriz [37] [5+i]='1';

matriz [37] [13]=matriz [37] [15]=matriz [40] [13]=matriz [40] [15]=matriz [3] [5]=1;
}

fase_7(){
int i,j;
x=y=20;
cim=bai=esq=dir=0;

xd=69; yd=10;
hor=1; ver=0;

xd2=50;yd2=10;
ver2=hor2=-1;

for (i=0;i<=24;i++)
	for(j=0;j<=2;j++)
		matriz [20+i] [15+j]=matriz [16+i] [11+j]='1';
for (i=5;i<=18;i=i+4)
	for (j=0;j<=70;j++) matriz [i+3+j] [i+j]='p';
matriz [23] [20]=' ';
for (i=0;i<=22;i=i+3)
	matriz [15+i] [10]=matriz [19+i] [14]=matriz [23+i] [18]='p';
matriz [58] [5]='p';
matriz [25] [5]='s';
matriz [77] [6]=matriz [62] [5]=3;
matriz [77] [7]=matriz [77] [5]='$';
}

fase_8(){
int i,j;
x=y=20;

xd=69; yd=5;
ver=hor=-1;

cim=bai=esq=dir=0;

for (i=0;i<=40;i++)
	matriz [10+i] [8]=matriz [10+i] [18]='p';
for (i=0;i<=10;i++)
	matriz [50] [8+i]=matriz [10] [8+i]='p';
matriz [40] [19]='b';
for (i=0;i<=20;i++)
	for (j=0;j<=5;j++) matriz [15+i] [10+j]='p';
	matriz [15] [9]='b';
	matriz [25] [13]='s';
	matriz [25] [14]=' ';
for (i=0;i<=10;i++)
	for (j=0;j<=4;j++)
		matriz [65+i] [10+j]='p';
matriz [4] [10]=matriz [25] [14]=matriz [35] [17]=matriz [68] [11]=matriz [74] [13]=1;
matriz [68] [13]=3;
matriz [74] [11]='$';
for (i=0;i<=4;i++)
	matriz [65] [6+i]='p';
for (i=0;i<=60;i++)
	matriz [5+i] [6]='p';
for (i=0;i<=15;i++)
	matriz [5] [6+i]='p';
matriz [5] [21]='b';
}

fase_9(){
int i,j;
x=y=20;
cim=bai=esq=dir=0;
tam=135;

xd=44; yd=14;
hor=1; ver=-1;

for (i=0;i<=60;i++)
	for (j=0;j<=14;j=j+3)
		matriz [10+i] [7+j]='p';
}

fase_10(){
int i,j;
x=y=20;
cim=bai=esq=dir=0;
tam=180;

xd=45;yd=10;
ver=1; hor=0;

xd2=65;yd2=16;
ver2=hor2=-1;

matriz [78] [5]='s';
for (i=0;i<=77;i++)
	matriz [3+i] [6]='p';
matriz [77] [5]=matriz [76] [5]='p';
for (i=0;i<=71;i++)
	matriz [4+i] [5]='1';
for (i=0;i<=1;i++)
	for (j=0;j<=3;j++)
		matriz [77+i] [7+j]='p';
for (i=0;i<=30;i++){
	for (j=0;j<=10;j++){
		matriz [30+i] [15]=matriz [30+i] [17]='p';
		matriz [44] [10+j]=matriz [46] [10+j]='p';
		matriz [36] [10+j]=matriz [38] [10+j]='p';
		matriz [52] [10+j]=matriz [54] [10+j]='p';
		}
		}
	for (i=0;i<=30;i++) matriz [30+i] [16]='1';
for (i=0;i<=18;i++)
	for (j=0;j<=8;j++)
	 matriz [9+i] [9+j]='1';
matriz [45] [15]=matriz [45] [17]=matriz [45] [16]=' ';
matriz [37] [15]=matriz [37] [17]=matriz [53] [15]=matriz [53] [17]=' ';
matriz [37] [11]=1;
matriz [53] [11]=1;
matriz [10] [5]=matriz [19] [14]=matriz [25] [15]=1;
matriz [37] [19]=3;
matriz [53] [19]='$';
for (i=0;i<=20;i++)
	matriz [8+i] [8]=matriz [8+i] [18]='p';
for (i=0;i<=10;i++)
	matriz [8] [8+i]=matriz [28] [8+i]='p';
matriz [9] [7]='b';
}

fase_livre(){
int i;
x=y=20;
troca(&xx,&yy);
cim=bai=esq=dir=0;
}



score(){
int i;
char nome[10];
zera();
carrega();
/*if (pnt>=matriz2[9].pnt){
	gotoxy(33,15);
	cprintf("Digite seu nome: %d",matriz2[9].pnt);
	scanf("%s",nome);
	ordena(nome);
	salva();
	} else */
ordena();
salva();
getch();
}


ordena(){
char jog[10];
int i,j,k;
for(i=0;i<=9;i++){
		if (pnt>=matriz2[i].pnt){
				gotoxy(33,15);
				cprintf("Digite seu nome: ");
				scanf("%s",jog);
			for(j=9;j>=i;j--){
					for (k=0;k<=9;k++)
					matriz2[j].nome[k]=matriz2[j-1].nome[k];
					matriz2[j].pnt=matriz2[j-1].pnt;
					matriz2[j].fase=matriz2[j-1].fase;
					}
				for (k=0;k<=9;k++)
				matriz2[i].nome[k]=jog[k];
				matriz2[i].pnt=pnt;
				matriz2[i].fase=fase;
				escreve(i);
				return 0;
				}

		}
gotoxy(13,15);
cprintf("! Voc%c n%co pontuou o suficiente para entrar no placar geral !",136,198);
gotoxy(33,16);
cprintf("Tente novamente.");
gotoxy(33,18);
cprintf("Pressione enter");
enter();
escreve();
}

salva(){
FILE *fp;
int i;

if ((fp=fopen("SCORE.DAT","w"))==NULL) {
	puts("Falhou Abertura! ");
	return;
 		}
for (i=0;i<=9;i++)
	if (*matriz2[i].nome)
		if (fwrite(&matriz2[i],sizeof(struct registro), 1,fp) != 1)
			puts("Falha na Gravacao! ");
	fclose(fp);

}

carrega(){
FILE *fp;
int i;

if ((fp=fopen("SCORE.DAT","rb")) == NULL){
	puts("Falha na Abertura do Arquivo!");
	return;
	}

zera();
for (i=0;i<=9;i++)
	if (fread(&matriz2[i], sizeof(struct registro), 1, fp) != 1) {
		if (feof(fp)) {
			fclose(fp);
				}
	else {
		puts("Erro de Leitura! ");
		fclose(fp);

      }
     }
}

escreve(int pos){
int i;
sc2();
printf("\n\n");
gotoxy(35,10);
textcolor(2);
textbackground(0);
cprintf("Placar Geral");
gotoxy(24,12);
cprintf(" pos.  nome     pontos        fase      ");
textcolor(0);
textbackground(14);
for(i=0;i<=9;i++) {
		if (i==pos) textcolor(3+225);
		else textcolor(i%2*2);
		gotoxy(25,13+i);
		cprintf("%d%c",i+1,248);
		gotoxy(29,13+i);
		cprintf("%s",matriz2[i].nome);
		gotoxy(39,13+i);
		cprintf("   %u",matriz2[i].pnt);
		gotoxy(49,13+i);
		if ((matriz2[i].fase>0)&&(matriz2[i].fase<=10))
			cprintf("   Miss%co %d",198,matriz2[i].fase);
		if (matriz2[i].fase==0)
			cprintf("   ZEROU!");
		if (matriz2[i].fase>90)
			cprintf("   Fase Livre");
		}
gotoxy(33,24);
textcolor(0);
cprintf("Pressione qualquer tecla para continuar");
}


zera(){
int i;
for (i=0;i<=9;i++)
	*matriz2[i].nome='\0';
	}